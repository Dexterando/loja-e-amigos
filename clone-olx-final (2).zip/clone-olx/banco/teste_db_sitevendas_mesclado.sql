-- =====================================================
-- teste_db_sitevendas_mesclado.sql
-- Estrutura oficial de banco.sql + dados originais de teste_db_sitevendas.sql
-- ATENCAO: apaga e recria as tabelas do db_sitevendas. Use apenas em ambiente de teste.
-- Senha dos usuarios de teste: 123456
-- =====================================================

SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS db_sitevendas;
USE db_sitevendas;

-- Limpeza na ordem das dependencias (tabelas filhas antes das pais)
DROP TABLE IF EXISTS pedido;
DROP TABLE IF EXISTS favoritos;
DROP TABLE IF EXISTS historico;
DROP TABLE IF EXISTS anuncios;
DROP TABLE IF EXISTS localizacao_cliente;
DROP TABLE IF EXISTS imagens;
DROP TABLE IF EXISTS categoria;
DROP TABLE IF EXISTS usuario;

-- ===== ESTRUTURA ORIGINAL DE banco.sql =====
CREATE TABLE IF NOT EXISTS categoria (
    id_categoria INT AUTO_INCREMENT NOT NULL,
    nome_categoria VARCHAR(256) NOT NULL,
    PRIMARY KEY (id_categoria)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS imagens (
    id_imagem INT AUTO_INCREMENT NOT NULL,
    caminho_imagem VARCHAR(256) NOT NULL,
    PRIMARY KEY (id_imagem)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS usuario (
    id_usuario INT AUTO_INCREMENT NOT NULL,
    nome_user VARCHAR(256) NOT NULL,
    senha_hash VARCHAR(256) NOT NULL,
    email_user VARCHAR(256) NOT NULL UNIQUE,
    data_nascimento DATE NOT NULL,
    vendedor BOOLEAN DEFAULT 0,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS localizacao_cliente (
    id_localizacao INT AUTO_INCREMENT NOT NULL,
    id_dono INT NOT NULL,
    cidade VARCHAR(150) NOT NULL,
    estado VARCHAR(2) NOT NULL,
    rua VARCHAR(150) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    numero VARCHAR(10) NOT NULL,
    complemento VARCHAR(256) NOT NULL,
    PRIMARY KEY (id_localizacao),
    FOREIGN KEY (id_dono) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS anuncios (
    id_anuncio INT AUTO_INCREMENT NOT NULL,
    id_dono INT NOT NULL,
    nome_anuncio VARCHAR(256) NOT NULL,
    descricao_anuncio TEXT NOT NULL,
    id_imagem INT NOT NULL,
    id_categoria INT NOT NULL,
    preco_centavos INT NOT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_anuncio),
    FOREIGN KEY (id_dono) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_imagem) REFERENCES imagens(id_imagem),
    FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS pedido (
    id_pedido INT AUTO_INCREMENT NOT NULL,
    id_vendedor INT NOT NULL,
    id_comprador INT NOT NULL,
    id_anuncio INT NOT NULL,
    id_localizacao INT NOT NULL,
    preco_centavos INT NOT NULL,
    status_pedido BOOLEAN,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_pedido),
    FOREIGN KEY (id_vendedor) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_comprador) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_anuncio) REFERENCES anuncios(id_anuncio),
    FOREIGN KEY (id_localizacao) REFERENCES localizacao_cliente(id_localizacao)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS favoritos (
    id_favorito INT AUTO_INCREMENT NOT NULL,
    id_dono INT NOT NULL,
    id_anuncio INT NOT NULL,
    PRIMARY KEY (id_favorito),
    FOREIGN KEY (id_dono) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_anuncio) REFERENCES anuncios(id_anuncio)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS historico (
    id_historico INT AUTO_INCREMENT NOT NULL,
    id_dono INT NOT NULL,
    descricao_historico TEXT NOT NULL,
    ocorrido_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_historico),
    FOREIGN KEY (id_dono) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;


-- ===== DADOS ORIGINAIS DE TESTE, AJUSTADOS PARA O SCHEMA OFICIAL =====
INSERT INTO usuario (id_usuario, nome_user, senha_hash, email_user, data_nascimento, vendedor) VALUES
(1, 'Ana Souza', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'ana@email.com', '2000-05-10', 1),
(2, 'Bruno Lima', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'bruno@email.com', '1994-02-21', 1),
(3, 'Carla Mendes', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'carla@email.com', '2003-09-03', 1),
(4, 'Diego Rocha', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'diego@email.com', '1985-12-30', 1),
(5, 'Elisa Martins', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'elisa@email.com', '1997-07-15', 0);

INSERT INTO categoria (id_categoria, nome_categoria) VALUES
(1, 'Celulares'), (2, 'Eletrônicos'), (3, 'Móveis'), (4, 'Roupas'), (5, 'Veículos'), (6, 'Esportes');

-- O teste original não fornecia imagens. São usados caminhos fictícios de placeholder
-- (um registro por anúncio para cumprir a FK NOT NULL; troque pelos arquivos reais).
INSERT INTO imagens (id_imagem, caminho_imagem) VALUES
(1, 'assets/imagens/teste/anuncio_01.jpg'), (2, 'assets/imagens/teste/anuncio_02.jpg'),
(3, 'assets/imagens/teste/anuncio_03.jpg'), (4, 'assets/imagens/teste/anuncio_04.jpg'),
(5, 'assets/imagens/teste/anuncio_05.jpg'), (6, 'assets/imagens/teste/anuncio_06.jpg'),
(7, 'assets/imagens/teste/anuncio_07.jpg'), (8, 'assets/imagens/teste/anuncio_08.jpg'),
(9, 'assets/imagens/teste/anuncio_09.jpg'), (10, 'assets/imagens/teste/anuncio_10.jpg'),
(11, 'assets/imagens/teste/anuncio_11.jpg'), (12, 'assets/imagens/teste/anuncio_12.jpg'),
(13, 'assets/imagens/teste/anuncio_13.jpg'), (14, 'assets/imagens/teste/anuncio_14.jpg'),
(15, 'assets/imagens/teste/anuncio_15.jpg'), (16, 'assets/imagens/teste/anuncio_16.jpg'),
(17, 'assets/imagens/teste/anuncio_17.jpg'), (18, 'assets/imagens/teste/anuncio_18.jpg'),
(19, 'assets/imagens/teste/anuncio_19.jpg'), (20, 'assets/imagens/teste/anuncio_20.jpg'),
(21, 'assets/imagens/teste/anuncio_21.jpg');

-- preco original (reais) convertido para centavos. cidade/estado/status/data_publicacao
-- não existem no schema oficial e, por isso, não são gravados como colunas.
INSERT INTO anuncios (id_anuncio, id_dono, nome_anuncio, descricao_anuncio, id_imagem, id_categoria, preco_centavos) VALUES
(1, 1, 'iPhone 13 128GB Azul', 'Bateria 89%, com caixa e carregador.', 1, 1, 280000),
(2, 3, 'Samsung Galaxy S23', 'Novo, lacrado, com nota fiscal.', 2, 1, 350000),
(3, 4, 'Xiaomi Redmi Note 12', 'Pouco uso, sem arranhões.', 3, 1, 90000),
(4, 2, 'iPhone 11 64GB Preto', 'Tela trocada, funcionando tudo.', 4, 1, 150000),
(5, 4, 'Notebook Dell Inspiron i5', '8GB RAM, SSD 256GB.', 5, 2, 220000),
(6, 1, 'Smart TV LG 50 polegadas', '4K, Wi-Fi, controle original.', 6, 2, 190000),
(7, 3, 'Fone Bluetooth JBL', 'Cancelamento de ruído, azul.', 7, 2, 35000),
(8, 2, 'Sofá 3 lugares cinza', 'Tecido suede, ótimo estado.', 8, 3, 75000),
(9, 4, 'Mesa de jantar 6 cadeiras', 'Madeira maciça.', 9, 3, 120000),
(10, 3, 'Guarda-roupa casal branco', '6 portas.', 10, 3, 98000),
(11, 1, 'Jaqueta de couro preta', 'Tamanho M, pouco usada.', 11, 4, 28000),
(12, 1, 'Tênis Nike Air Max 42', 'Original, na caixa.', 12, 4, 45000),
(13, 4, 'Honda CG 160 2020', '25 mil km, documentação ok.', 13, 5, 1350000),
(14, 2, 'Fiat Uno 2012', 'Completo, revisado.', 14, 5, 2200000),
(15, 3, 'Bicicleta aro 29', '21 marchas, freio a disco.', 15, 6, 110000),
(16, 3, 'Bola de futebol Adidas', 'Oficial, nova.', 16, 6, 15000),
(17, 1, 'Esteira elétrica', 'Dobrável, 12 km/h.', 17, 6, 160000),
(18, 2, 'Videogame PlayStation 5', 'Com 2 controles e 3 jogos.', 18, 2, 380000),
(19, 3, 'Cadeira gamer roxa', 'Reclinável, apoio de braço.', 19, 3, 65000),
(20, 4, 'Capinha iPhone 13', 'Silicone, várias cores.', 20, 1, 3000),
(21, 1, 'Câmera Canon T6', 'Com lente 18-55mm e bolsa.', 21, 2, 170000);

-- Favoritos originais da Elisa, IDs dos anúncios mantidos.
INSERT INTO favoritos (id_dono, id_anuncio) VALUES
(5, 1), (5, 8), (5, 15);

-- Datas diferentes para testar a ordenação "Mais recentes" / "Mais antigos".
UPDATE anuncios SET criado_em = CASE id_anuncio
    WHEN 1 THEN '2026-11-01 10:00:00'  WHEN 2 THEN '2026-11-10 14:30:00'  WHEN 3 THEN '2026-10-20 09:15:00'
    WHEN 4 THEN '2026-11-18 16:00:00'  WHEN 5 THEN '2026-11-05 16:00:00'  WHEN 6 THEN '2026-11-15 11:20:00'
    WHEN 7 THEN '2026-11-19 08:45:00'  WHEN 8 THEN '2026-10-28 13:00:00'  WHEN 9 THEN '2026-11-02 17:40:00'
    WHEN 10 THEN '2026-11-12 10:10:00' WHEN 11 THEN '2026-11-08 15:25:00' WHEN 12 THEN '2026-11-20 12:00:00'
    WHEN 13 THEN '2026-10-15 09:00:00' WHEN 14 THEN '2026-11-09 10:30:00' WHEN 15 THEN '2026-11-11 18:00:00'
    WHEN 16 THEN '2026-11-21 07:30:00' WHEN 17 THEN '2026-11-14 19:00:00' WHEN 18 THEN '2026-11-22 09:00:00'
    WHEN 19 THEN '2026-11-16 20:00:00' WHEN 20 THEN '2026-11-23 08:00:00' WHEN 21 THEN '2026-10-10 10:00:00'
END;

-- Localização de cada usuário (a cidade/estado do anúncio vem daqui, pelo id_dono).
INSERT INTO localizacao_cliente (id_dono, cidade, estado, rua, cep, numero, complemento) VALUES
(1, 'São Paulo',      'SP', 'Av. Paulista',   '01310-100', '1000', 'Apto 12'),
(2, 'Campinas',       'SP', 'Rua Barão',      '13010-000', '50',   ''),
(3, 'Rio de Janeiro', 'RJ', 'Rua Primeiro',   '20040-000', '12',   'Casa'),
(4, 'Belo Horizonte', 'MG', 'Rua Pernambuco', '30110-000', '300',  ''),
(5, 'Curitiba',       'PR', 'Rua XV',         '80010-000', '88',   'Bloco B');

-- Pedidos e histórico ficam criados e vazios.
