<?php
// conexao.php PROVISÓRIO (o oficial é do grupo do banco)
// Mesmo jeito de conectar usado no cadastro, login e perfil (mysqli).

$servidor   = "localhost";
$usuario    = "root";
$senhaBanco = "";            // se o seu MySQL tiver senha, coloque aqui
$banco      = "db_sitevendas";

$conexao = new mysqli($servidor, $usuario, $senhaBanco, $banco);

if ($conexao->connect_error) {
    die("Erro na conexao com o banco.");
}

$conexao->set_charset("utf8mb4");
