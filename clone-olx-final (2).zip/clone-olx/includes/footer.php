<?php
// Descobre o caminho público da pasta do projeto, sem presumir o nome dela.
$projectPath = str_replace('\\', '/', realpath(__DIR__ . '/..'));
$documentPath = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
$baseUrl = str_replace($documentPath, '', $projectPath);
$baseUrl = '/' . trim($baseUrl, '/');
?>

<footer class="site-footer">

    <div class="footer-container">

        <!-- IDENTIDADE -->
        <div class="footer-column footer-brand">

            <img src="<?= htmlspecialchars($baseUrl . '/assets/imagens/logo.jpg', ENT_QUOTES, 'UTF-8') ?>"
                 alt="Loja e Amigos">

            <p>
                Encontre oportunidades incríveis e
                faça bons negócios com a Loja e Amigos.
            </p>

        </div>

        <!-- SOBRE -->
        <div class="footer-column">

            <h3>Sobre nós</h3>

            <a href="#">Quem somos</a>
            <a href="#">Como funciona</a>
            <a href="#">Contato</a>

        </div>

        <!-- AJUDA -->
        <div class="footer-column">

            <h3>Ajuda</h3>

            <a href="#">Central de ajuda</a>
            <a href="#">Dúvidas frequentes</a>
            <a href="#">Segurança</a>
            <a href="#">Termos de uso</a>

        </div>

        <!-- CONTA -->
        <div class="footer-column">

            <h3>Minha conta</h3>

            <a href="/clone-olx/usuarios/login.php">
                Entrar
            </a>

            <a href="/clone-olx/usuarios/cadastro.php">
                Cadastrar
            </a>

            <a href="#">Meus anúncios</a>
            <a href="#">Favoritos</a>

        </div>

    </div>

    <!-- COPYRIGHT -->
    <div class="footer-bottom">

        <p>
            &copy; <?php echo date('Y'); ?>
            Loja e Amigos. Todos os direitos reservados.
        </p>

        <p>Produzida por Igor e Amigos</p>

    </div>

</footer>
