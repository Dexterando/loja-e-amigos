<?php
// Descobre o caminho público da pasta do projeto, sem presumir o nome dela.
$projectPath = str_replace('\\', '/', realpath(__DIR__ . '/..'));
$documentPath = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
$baseUrl = str_replace($documentPath, '', $projectPath);
$baseUrl = '/' . trim($baseUrl, '/');

// Garante que a conexão esteja disponível mesmo em páginas que não a incluíram.
if (!isset($conexao) || !($conexao instanceof mysqli)) {
    require_once __DIR__ . '/../conexao.php';
}

// Busca as categorias cadastradas no banco de dados.
$categoriasHeader = [];
$resultadoCategoriasHeader = $conexao->query(
    'SELECT id_categoria, nome_categoria FROM categoria ORDER BY nome_categoria ASC'
);

if ($resultadoCategoriasHeader) {
    while ($categoriaHeader = $resultadoCategoriasHeader->fetch_assoc()) {
        $categoriasHeader[] = $categoriaHeader;
    }
    $resultadoCategoriasHeader->free();
}
?>

<header class="site-header">

    <div class="header-container">

        <!-- LOGO -->
        <a href="/clone-olx/index.php" class="logo">
            <img src="<?= htmlspecialchars($baseUrl . '/assets/imagens/logo.jpg', ENT_QUOTES, 'UTF-8') ?>"
                 alt="Loja e Amigos">
        </a>

        <!-- LOCALIZAÇÃO -->
        <div class="location-box">
            <span class="location-icon">⌖</span>

            <div>
                <small>Você está em</small>
                <strong>Escolher localização</strong>
            </div>
        </div>

        <!-- PESQUISA -->
        <form action="/clone-olx/anuncios/pesquisar.php" method="GET" class="search-box">

            <input
                type="search"
                name="busca"
                placeholder="O que você está procurando?"
            >

            <button type="submit">Pesquisar</button>

        </form>

        <!-- AÇÕES -->
        <nav class="header-actions">

            <a href="/clone-olx/usuarios/login.php">
                Entrar
            </a>

            <a href="/clone-olx/usuarios/cadastro.php">
                Cadastrar
            </a>

            <a href="/clone-olx/anuncios/publicar.php"
               class="btn-anunciar">
                Anunciar grátis
            </a>

        </nav>

    </div>

    <!-- CATEGORIAS -->
    <div class="header-categories">

        <nav>
            <a href="<?= htmlspecialchars($baseUrl . '/anuncios/pesquisar.php', ENT_QUOTES, 'UTF-8') ?>">
                Todas as categorias
            </a>

            <?php foreach ($categoriasHeader as $categoriaHeader): ?>
                <a href="<?= htmlspecialchars(
                    $baseUrl . '/anuncios/pesquisar.php?categoria=' . (int) $categoriaHeader['id_categoria'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>">
                    <?= htmlspecialchars($categoriaHeader['nome_categoria'], ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php endforeach; ?>
        </nav>

    </div>

</header>
