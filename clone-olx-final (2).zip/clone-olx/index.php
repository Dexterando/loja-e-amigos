<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Loja e Amigos | Classificados</title>

    <link rel="stylesheet"
          href="assets/css/style.css">

</head>

<body>

    <?php include 'includes/header.php'; ?>

    <main>

        <!--
            CONTEÚDO DA PÁGINA INICIAL
            Vamos desenvolver posteriormente.
        -->

    </main>

    <?php include 'includes/footer.php'; ?>

</body>

</html>
