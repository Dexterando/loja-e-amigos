
<?php

session_start();


// CONEXAO COM O BANCO (dados da conexao ficam no conexao.php)

include "../conexao.php";


// VARIAVEL DA MENSAGEM

$mensagem = "";


// VERIFICAR ENVIO DO FORMULARIO

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"]);
    $senhaUsuario = $_POST["senha"];


    // BUSCAR USUARIO PELO EMAIL

    $consulta = $conexao->prepare(
        "SELECT id_usuario, nome_user, email_user, senha_hash, data_nascimento, vendedor
        FROM usuario WHERE email_user = ?"
    );

    $consulta->bind_param("s", $email);
    $consulta->execute();

    $consulta->bind_result(
        $idUsuario,
        $nomeUsuario,
        $emailUsuario,
        $senhaHash,
        $dataNascimento,
        $vendedor
    );


    // VERIFICAR SE O USUARIO EXISTE

    if ($consulta->fetch()) {

        // CONFERIR A SENHA

        if (password_verify($senhaUsuario, $senhaHash)) {

            session_regenerate_id(true);

            $_SESSION["id_usuario"] = $idUsuario;

            $consulta->close();
            $conexao->close();

            header("Location: perfil.php");
            exit;

        } else {

            $mensagem = "E-mail ou senha incorretos.";

        }

    } else {

        $mensagem = "E-mail ou senha incorretos.";

    }

    $consulta->close();
}

$conexao->close();

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login - Loja e Amigos</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f2fa;
            color: #302442;
        }

        header {
            background-color: white;
            padding: 15px 30px;
            border-bottom: 1px solid #e6e0ef;
        }

        header img {
            width: 220px;
            height: auto;
        }

        main {
            display: flex;
            justify-content: center;
            padding: 60px 15px;
        }

        .caixa {
            background-color: white;
            width: 100%;
            max-width: 420px;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.06);
        }

        h1 {
            color: #6f2dbd;
            font-size: 26px;
        }

        .campo {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ded7e8;
            border-radius: 6px;
        }

        .botao {
            width: 100%;
            padding: 13px;
            background-color: #6f2dbd;
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }

        .botao:hover {
            background-color: #572096;
        }

        .mensagem {
            background-color: #fff0f0;
            color: #bd3030;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .link {
            text-align: center;
            font-size: 14px;
            margin-top: 20px;
        }

        a {
            color: #6f2dbd;
        }

    </style>

</head>

<body>

    <header>

        <a href="../index.php">
            <img src="../assets/imagens/logo.jpg" alt="Loja e Amigos">
        </a>

    </header>

    <main>

        <div class="caixa">

            <h1>Bem-vindo de volta!</h1>

            <p>Entre na sua conta da Loja e Amigos.</p>

            <?php

            if ($mensagem != "") {

                echo "<div class='mensagem'>";
                echo htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8");
                echo "</div>";

            }

            ?>

            <form method="POST" action="">

                <div class="campo">

                    <label for="email">E-mail</label>

                    <input
                        type="email"
                        name="email"
                        id="email"
                        placeholder="Digite seu e-mail"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="senha">Senha</label>

                    <input
                        type="password"
                        name="senha"
                        id="senha"
                        placeholder="Digite sua senha"
                        required
                    >

                </div>

                <button type="submit" class="botao">
                    Entrar
                </button>

            </form>

            <div class="link">

                Ainda não possui uma conta?
                <a href="cadastro.php">Cadastre-se</a>

            </div>

        </div>

    </main>

</body>

</html>
