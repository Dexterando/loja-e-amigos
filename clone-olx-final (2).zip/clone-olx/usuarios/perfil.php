<?php

session_start();


// VERIFICAR SE O USUARIO ESTA LOGADO

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

$idLogado = (int) $_SESSION["id_usuario"];


// TOKEN DE SEGURANCA PARA OS FORMULARIOS (CSRF)

if (!isset($_SESSION["token"])) {
    $_SESSION["token"] = bin2hex(random_bytes(32));
}


// CONEXAO COM O BANCO (dados da conexao ficam no conexao.php)

include "../conexao.php";


// VARIAVEIS

$mensagem = "";
$aba = "anuncios";

if (isset($_GET["aba"])) {
    if ($_GET["aba"] == "favoritos") {
        $aba = "favoritos";
    }
}


// VERIFICAR ENVIO DE FORMULARIOS (SAIR / REMOVER FAVORITO)

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $tokenEnviado = "";

    if (isset($_POST["token"])) {
        $tokenEnviado = $_POST["token"];
    }

    $acao = "";

    if (isset($_POST["acao"])) {
        $acao = $_POST["acao"];
    }

    if (hash_equals($_SESSION["token"], $tokenEnviado) == false) {

        $mensagem = "Requisicao invalida. Tente novamente.";

    } elseif ($acao == "sair") {

        $conexao->close();

        $_SESSION = array();
        session_destroy();

        header("Location: login.php");
        exit;

    } elseif ($acao == "remover_favorito") {

        $idAnuncioRemover = 0;

        if (isset($_POST["id_anuncio"])) {
            $idAnuncioRemover = (int) $_POST["id_anuncio"];
        }

        $remocao = $conexao->prepare(
            "DELETE FROM favoritos WHERE id_dono = ? AND id_anuncio = ?"
        );

        $remocao->bind_param("ii", $idLogado, $idAnuncioRemover);
        $remocao->execute();
        $remocao->close();

        $conexao->close();

        header("Location: perfil.php?aba=favoritos&removido=1");
        exit;
    }
}

if (isset($_GET["removido"])) {
    $mensagem = "Anuncio removido dos favoritos.";
}


// BUSCAR DADOS DO USUARIO

$consulta = $conexao->prepare(
    "SELECT nome_user, email_user, data_nascimento, vendedor
    FROM usuario WHERE id_usuario = ?"
);

$consulta->bind_param("i", $idLogado);
$consulta->execute();

$consulta->bind_result(
    $nomeUsuario,
    $emailUsuario,
    $dataNascimento,
    $vendedor
);

if ($consulta->fetch() == false) {

    // USUARIO NAO EXISTE MAIS NO BANCO

    $consulta->close();
    $conexao->close();

    $_SESSION = array();
    session_destroy();

    header("Location: login.php");
    exit;
}

$consulta->close();


// CALCULAR IDADE E FORMATAR DATA

$dataNascimentoFormatada = "";
$idade = 0;

$objetoNascimento = DateTime::createFromFormat("Y-m-d", $dataNascimento);

if ($objetoNascimento != false) {

    $hoje = new DateTime("today");
    $idade = $hoje->diff($objetoNascimento)->y;
    $dataNascimentoFormatada = $objetoNascimento->format("d/m/Y");
}

$inicialNome = mb_strtoupper(mb_substr($nomeUsuario, 0, 1, "UTF-8"), "UTF-8");

$tipoConta = "Comprador";

if ($vendedor == 1) {
    $tipoConta = "Vendedor";
}


// BUSCAR ANUNCIOS PUBLICADOS PELO USUARIO

$listaAnuncios = array();

$consultaAnuncios = $conexao->prepare(
    "SELECT a.id_anuncio, a.nome_anuncio, a.preco_centavos / 100.0,
            COALESCE(lc.cidade, ''), COALESCE(i.caminho_imagem, ''), 'ativo', a.criado_em
    FROM anuncios a
    LEFT JOIN imagens i ON i.id_imagem = a.id_imagem
    LEFT JOIN localizacao_cliente lc ON lc.id_localizacao = (
        SELECT MAX(l2.id_localizacao) FROM localizacao_cliente l2 WHERE l2.id_dono = a.id_dono
    )
    WHERE a.id_dono = ?
    ORDER BY a.criado_em DESC"
);

$consultaAnuncios->bind_param("i", $idLogado);
$consultaAnuncios->execute();

$consultaAnuncios->bind_result(
    $anuncioId,
    $anuncioTitulo,
    $anuncioPreco,
    $anuncioCidade,
    $anuncioImagem,
    $anuncioStatus,
    $anuncioData
);

while ($consultaAnuncios->fetch()) {

    $listaAnuncios[] = array(
        "id" => $anuncioId,
        "titulo" => $anuncioTitulo,
        "preco" => $anuncioPreco,
        "cidade" => $anuncioCidade,
        "imagem" => $anuncioImagem,
        "status" => $anuncioStatus,
        "data" => $anuncioData
    );
}

$consultaAnuncios->close();


// BUSCAR FAVORITOS DO USUARIO

$listaFavoritos = array();

$consultaFavoritos = $conexao->prepare(
    "SELECT a.id_anuncio, a.nome_anuncio, a.preco_centavos / 100.0,
            COALESCE(lc.cidade, ''), COALESCE(i.caminho_imagem, ''), 'ativo', u.nome_user
    FROM favoritos f
    INNER JOIN anuncios a ON a.id_anuncio = f.id_anuncio
    INNER JOIN usuario u ON u.id_usuario = a.id_dono
    LEFT JOIN imagens i ON i.id_imagem = a.id_imagem
    LEFT JOIN localizacao_cliente lc ON lc.id_localizacao = (
        SELECT MAX(l2.id_localizacao) FROM localizacao_cliente l2 WHERE l2.id_dono = a.id_dono
    )
    WHERE f.id_dono = ?
    ORDER BY f.id_favorito DESC"
);

$consultaFavoritos->bind_param("i", $idLogado);
$consultaFavoritos->execute();

$consultaFavoritos->bind_result(
    $favoritoId,
    $favoritoTitulo,
    $favoritoPreco,
    $favoritoCidade,
    $favoritoImagem,
    $favoritoStatus,
    $favoritoVendedor
);

while ($consultaFavoritos->fetch()) {

    $listaFavoritos[] = array(
        "id" => $favoritoId,
        "titulo" => $favoritoTitulo,
        "preco" => $favoritoPreco,
        "cidade" => $favoritoCidade,
        "imagem" => $favoritoImagem,
        "status" => $favoritoStatus,
        "vendedor" => $favoritoVendedor
    );
}

$consultaFavoritos->close();

$conexao->close();

$totalAnuncios = count($listaAnuncios);
$totalFavoritos = count($listaFavoritos);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Meu perfil - Loja e Amigos</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f2fa;
            color: #302442;
        }

        header {
            background-color: white;
            padding: 15px 30px;
            border-bottom: 1px solid #e6e0ef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header img {
            width: 220px;
            height: auto;
        }

        .botao-sair {
            padding: 10px 18px;
            background-color: white;
            color: #6f2dbd;
            border: 1px solid #6f2dbd;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }

        .botao-sair:hover {
            background-color: #eee5fa;
        }

        main {
            max-width: 960px;
            margin: 0 auto;
            padding: 40px 15px;
        }

        .caixa {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.06);
            margin-bottom: 25px;
        }

        h1 {
            color: #6f2dbd;
            font-size: 25px;
            margin-top: 0;
        }

        h2 {
            color: #6f2dbd;
            font-size: 20px;
            margin-top: 0;
        }

        .mensagem {
            background-color: #eee5fa;
            color: #572096;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .topo-perfil {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #6f2dbd;
            color: white;
            font-size: 34px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .topo-perfil h1 {
            margin-bottom: 5px;
        }

        .etiqueta {
            display: inline-block;
            background-color: #eee5fa;
            color: #572096;
            font-size: 12px;
            font-weight: bold;
            padding: 4px 10px;
            border-radius: 20px;
        }

        .dados {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 18px;
        }

        .dado-titulo {
            font-size: 13px;
            font-weight: bold;
            color: #7d718f;
            margin-bottom: 5px;
        }

        .dado-valor {
            font-size: 15px;
            word-break: break-word;
        }

        .abas {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            border-bottom: 1px solid #e6e0ef;
        }

        .aba {
            padding: 12px 20px;
            text-decoration: none;
            color: #7d718f;
            font-weight: bold;
            font-size: 14px;
            border-bottom: 3px solid transparent;
        }

        .aba:hover {
            color: #6f2dbd;
        }

        .aba-ativa {
            color: #6f2dbd;
            border-bottom: 3px solid #6f2dbd;
        }

        .lista {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }

        .cartao {
            border: 1px solid #e6e0ef;
            border-radius: 10px;
            overflow: hidden;
            background-color: white;
            display: flex;
            flex-direction: column;
        }

        .cartao-imagem {
            width: 100%;
            height: 160px;
            object-fit: cover;
            display: block;
            background-color: #eee5fa;
        }

        .sem-imagem {
            width: 100%;
            height: 160px;
            background-color: #eee5fa;
            color: #8e51d4;
            font-size: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .cartao-corpo {
            padding: 15px;
            display: flex;
            flex-direction: column;
            gap: 6px;
            flex-grow: 1;
        }

        .cartao-preco {
            font-size: 20px;
            font-weight: bold;
            color: #302442;
        }

        .cartao-titulo {
            font-size: 14px;
            color: #302442;
            text-decoration: none;
        }

        .cartao-titulo:hover {
            color: #6f2dbd;
            text-decoration: underline;
        }

        .cartao-info {
            font-size: 12px;
            color: #7d718f;
        }

        .status-ativo {
            color: #2d8a4e;
            font-weight: bold;
        }

        .status-vendido {
            color: #bd3030;
            font-weight: bold;
        }

        .botao-remover {
            width: 100%;
            margin-top: 8px;
            padding: 10px;
            background-color: #fff0f0;
            color: #bd3030;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 13px;
            cursor: pointer;
        }

        .botao-remover:hover {
            background-color: #fadcdc;
        }

        .botao {
            display: inline-block;
            padding: 13px 25px;
            background-color: #6f2dbd;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 14px;
        }

        .botao:hover {
            background-color: #572096;
        }

        .vazio {
            text-align: center;
            padding: 30px 10px;
            color: #7d718f;
            font-size: 14px;
        }

        .vazio p {
            margin-bottom: 20px;
        }

        a {
            color: #6f2dbd;
        }

    </style>

</head>

<body>

    <header>

        <a href="../index.php">
            <img src="../assets/imagens/logo.jpg" alt="Loja e Amigos">
        </a>

        <form method="POST" action="perfil.php">

            <input
                type="hidden"
                name="token"
                value="<?php echo htmlspecialchars($_SESSION["token"], ENT_QUOTES, "UTF-8"); ?>"
            >

            <input type="hidden" name="acao" value="sair">

            <button type="submit" class="botao-sair">
                Sair
            </button>

        </form>

    </header>

    <main>

        <?php

        if ($mensagem != "") {

            echo "<div class='mensagem'>";
            echo htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8");
            echo "</div>";

        }

        ?>


        <!-- INFORMACOES GERAIS -->

        <div class="caixa">

            <div class="topo-perfil">

                <div class="avatar">
                    <?php echo htmlspecialchars($inicialNome, ENT_QUOTES, "UTF-8"); ?>
                </div>

                <div>

                    <h1><?php echo htmlspecialchars($nomeUsuario, ENT_QUOTES, "UTF-8"); ?></h1>

                    <span class="etiqueta">
                        <?php echo htmlspecialchars($tipoConta, ENT_QUOTES, "UTF-8"); ?>
                    </span>

                </div>

            </div>

            <div class="dados">

                <div>
                    <div class="dado-titulo">E-mail</div>
                    <div class="dado-valor">
                        <?php echo htmlspecialchars($emailUsuario, ENT_QUOTES, "UTF-8"); ?>
                    </div>
                </div>

                <div>
                    <div class="dado-titulo">Data de nascimento</div>
                    <div class="dado-valor">
                        <?php echo htmlspecialchars($dataNascimentoFormatada, ENT_QUOTES, "UTF-8"); ?>
                        (<?php echo (int) $idade; ?> anos)
                    </div>
                </div>

                <div>
                    <div class="dado-titulo">Anúncios publicados</div>
                    <div class="dado-valor"><?php echo $totalAnuncios; ?></div>
                </div>

                <div>
                    <div class="dado-titulo">Favoritos</div>
                    <div class="dado-valor"><?php echo $totalFavoritos; ?></div>
                </div>

            </div>

        </div>


        <!-- ABAS (NAVEGACAO POR LINK, SEM JAVASCRIPT) -->

        <div class="abas">

            <?php

            $classeAbaAnuncios = "aba";
            $classeAbaFavoritos = "aba";

            if ($aba == "anuncios") {
                $classeAbaAnuncios = "aba aba-ativa";
            } else {
                $classeAbaFavoritos = "aba aba-ativa";
            }

            echo "<a class='" . $classeAbaAnuncios . "' href='perfil.php?aba=anuncios'>";
            echo "Meus anúncios (" . $totalAnuncios . ")";
            echo "</a>";

            echo "<a class='" . $classeAbaFavoritos . "' href='perfil.php?aba=favoritos'>";
            echo "Favoritos (" . $totalFavoritos . ")";
            echo "</a>";

            ?>

        </div>


        <?php

        if ($aba == "anuncios") {

        ?>

        <!-- ANUNCIOS PUBLICADOS -->

        <div class="caixa">

            <h2>Meus anúncios</h2>

            <?php

            if ($totalAnuncios == 0) {

                echo "<div class='vazio'>";

                if ($vendedor == 1) {
                    echo "<p>Você ainda não publicou nenhum anúncio.</p>";
                    echo "<a class='botao' href='../anuncios/publicar.php'>Publicar anúncio</a>";
                } else {
                    echo "<p>Sua conta não está cadastrada como vendedor, por isso não há anúncios publicados.</p>";
                }

                echo "</div>";

            } else {

                echo "<div class='lista'>";

                foreach ($listaAnuncios as $anuncio) {

                    $precoFormatado = number_format((float) $anuncio["preco"], 2, ",", ".");
                    $dataFormatada = date("d/m/Y", strtotime($anuncio["data"]));

                    $classeStatus = "status-ativo";
                    $textoStatus = "Ativo";

                    if ($anuncio["status"] == "vendido") {
                        $classeStatus = "status-vendido";
                        $textoStatus = "Vendido";
                    }

                    echo "<div class='cartao'>";

                    if ($anuncio["imagem"] != "") {
                        echo "<img class='cartao-imagem' src='../" . htmlspecialchars($anuncio["imagem"], ENT_QUOTES, "UTF-8") . "' alt='" . htmlspecialchars($anuncio["titulo"], ENT_QUOTES, "UTF-8") . "'>";
                    } else {
                        echo "<div class='sem-imagem'>Sem imagem</div>";
                    }

                    echo "<div class='cartao-corpo'>";

                    echo "<div class='cartao-preco'>R$ " . $precoFormatado . "</div>";

                    echo "<a class='cartao-titulo' href='../anuncios/detalhes.php?id=" . (int) $anuncio["id"] . "'>";
                    echo htmlspecialchars($anuncio["titulo"], ENT_QUOTES, "UTF-8");
                    echo "</a>";

                    echo "<div class='cartao-info'>";
                    echo htmlspecialchars($anuncio["cidade"], ENT_QUOTES, "UTF-8");
                    echo " &middot; Publicado em " . $dataFormatada;
                    echo "</div>";

                    echo "<div class='cartao-info'>";
                    echo "<span class='" . $classeStatus . "'>" . $textoStatus . "</span>";
                    echo "</div>";

                    echo "</div>";
                    echo "</div>";
                }

                echo "</div>";
            }

            ?>

        </div>

        <?php

        } else {

        ?>

        <!-- FAVORITOS -->

        <div class="caixa">

            <h2>Favoritos</h2>

            <?php

            if ($totalFavoritos == 0) {

                echo "<div class='vazio'>";
                echo "<p>Você ainda não favoritou nenhum anúncio.</p>";
                echo "<a class='botao' href='../index.php'>Explorar anúncios</a>";
                echo "</div>";

            } else {

                echo "<div class='lista'>";

                foreach ($listaFavoritos as $favorito) {

                    $precoFormatado = number_format((float) $favorito["preco"], 2, ",", ".");

                    $classeStatus = "status-ativo";
                    $textoStatus = "Ativo";

                    if ($favorito["status"] == "vendido") {
                        $classeStatus = "status-vendido";
                        $textoStatus = "Vendido";
                    }

                    echo "<div class='cartao'>";

                    if ($favorito["imagem"] != "") {
                        echo "<img class='cartao-imagem' src='../" . htmlspecialchars($favorito["imagem"], ENT_QUOTES, "UTF-8") . "' alt='" . htmlspecialchars($favorito["titulo"], ENT_QUOTES, "UTF-8") . "'>";
                    } else {
                        echo "<div class='sem-imagem'>Sem imagem</div>";
                    }

                    echo "<div class='cartao-corpo'>";

                    echo "<div class='cartao-preco'>R$ " . $precoFormatado . "</div>";

                    echo "<a class='cartao-titulo' href='../anuncios/detalhes.php?id=" . (int) $favorito["id"] . "'>";
                    echo htmlspecialchars($favorito["titulo"], ENT_QUOTES, "UTF-8");
                    echo "</a>";

                    echo "<div class='cartao-info'>";
                    echo htmlspecialchars($favorito["cidade"], ENT_QUOTES, "UTF-8");
                    echo " &middot; Vendedor: " . htmlspecialchars($favorito["vendedor"], ENT_QUOTES, "UTF-8");
                    echo "</div>";

                    echo "<div class='cartao-info'>";
                    echo "<span class='" . $classeStatus . "'>" . $textoStatus . "</span>";
                    echo "</div>";

                    echo "<form method='POST' action='perfil.php?aba=favoritos'>";
                    echo "<input type='hidden' name='token' value='" . htmlspecialchars($_SESSION["token"], ENT_QUOTES, "UTF-8") . "'>";
                    echo "<input type='hidden' name='acao' value='remover_favorito'>";
                    echo "<input type='hidden' name='id_anuncio' value='" . (int) $favorito["id"] . "'>";
                    echo "<button type='submit' class='botao-remover'>Remover dos favoritos</button>";
                    echo "</form>";

                    echo "</div>";
                    echo "</div>";
                }

                echo "</div>";
            }

            ?>

        </div>

        <?php

        }

        ?>

    </main>

</body>

</html>
