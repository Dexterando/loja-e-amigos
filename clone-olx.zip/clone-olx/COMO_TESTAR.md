# Como testar o projeto (banco db_sitevendas)

## Arquivos PROVISÓRIOS (serão trocados pelos oficiais)
- `conexao.php`
- `includes/header.php` e `includes/footer.php`
- `banco/teste_db_sitevendas_mesclado.sql` (estrutura oficial do `banco.sql` + dados de teste)
- `assets/imagens/teste/` (imagens dos anúncios de teste)

## Passo a passo no LARAGON
1. Pause o OneDrive (ícone da nuvem > Pausar sincronização).
2. Abra o Laragon e clique em **Iniciar Tudo**.
3. Deixe a pasta assim: `...\laragon\www\clone-olx\anuncios\...`
4. Importe o banco, entrando no MySQL em UTF-8 (no Terminal do Laragon):
   ```
   mysql -u root -p --default-character-set=utf8mb4
   ```
   Depois, dentro do `mysql>`:
   ```
   source C:/caminho/até/laragon/www/clone-olx/banco/teste_db_sitevendas_mesclado.sql
   ```
   (caminho com `/` e sem aspas) — ou use o HeidiSQL: **Arquivo > Executar arquivo SQL...**
5. Se o seu MySQL tem senha, coloque a senha **só no `conexao.php`** (variável `$senhaBanco`).
   Todas as páginas usam esse arquivo.

## Endereços
- Pesquisa: `http://localhost/clone-olx/anuncios/pesquisar.php`
- Login: `http://localhost/clone-olx/usuarios/login.php`
- Cadastro: `http://localhost/clone-olx/usuarios/cadastro.php`

## Usuários de teste (senha de todos: `123456`)
| E-mail | Tipo | Bom para testar |
|---|---|---|
| `ana@email.com` | vendedor | perfil com vários anúncios |
| `elisa@email.com` | comprador | aba Favoritos (tem 3) |

## Testes da pesquisa
| Teste | O que deve acontecer |
|---|---|
| Abrir sem filtro | 21 anúncios, mais recentes primeiro, 2 páginas |
| Buscar `iphone` | 3 resultados |
| Buscar `iphone azul` | Só o "iPhone 13 128GB Azul" |
| Categoria **Celulares** + **Menor preço** | Começa pela Capinha (R$ 30,00) |
| Estado **SP** + preço máximo **1000** | Tênis, Jaqueta e Sofá |
| Cidade `campinas` | 4 anúncios |
| Clicar numa categoria no topo do site | Abre a pesquisa já filtrada |
| Buscar pela caixa do topo do site | Abre a pesquisa com o resultado |
| Preço mínimo **10000** + **Maior preço** | Fiat Uno, depois Honda CG |
| Buscar `xyz123` | "Nenhum anúncio encontrado" |
| Página 2 com filtros | Os filtros continuam aplicados |

## Se der erro
- **"Erro na conexao com o banco"**: banco não importado ou senha do MySQL errada.
- **Acentos estranhos (Ã´, ├┤)**: importe de novo pelo passo 4 (com `--default-character-set=utf8mb4`).
- **"Schema directory already exists"**: pare o MySQL, apague a pasta `db_sitevendas`
  em `laragon\data\mysql-...\`, inicie de novo e importe.
- **Página sem cor**: a pasta não está em `www\clone-olx\`.
- **Links "Publicar anúncio" e anúncios do perfil dão erro 404**: normal,
  `publicar.php` e `detalhes.php` ainda não chegaram.
