# Módulo de Pesquisa e Filtros — clone-olx

## Arquivos
| Arquivo | O que faz |
|---|---|
| `anuncios/Pesquisa.php` | Classe `Pesquisa`: lê os filtros, monta o SQL e busca os anúncios |
| `anuncios/pesquisar.php` | Página da pesquisa: usa a classe e mostra filtros, cards e paginação |
| `includes/barra_pesquisa.php` | Campo de busca para colocar no topo do site |
| `assets/css/pesquisa.css` | Estilo da pesquisa, roxo e branco (separado do style.css do grupo) |

## Banco usado: db_sitevendas
A classe recebe a conexão `$conexao` (mysqli) do `conexao.php` no construtor e usa estas tabelas/colunas
(as categorias vêm do método `listarCategorias()` da classe `Anuncio`):

| Tabela | Colunas usadas |
|---|---|
| `anuncios` | `id_anuncio`, `id_dono`, `nome_anuncio`, `descricao_anuncio`, `preco_centavos`, `id_imagem`, `id_categoria`, `criado_em` |
| `categoria` | `id_categoria`, `nome_categoria` |
| `imagens` | `id_imagem`, `caminho_imagem` |
| `localizacao_cliente` | `id_dono`, `cidade`, `estado` (cidade/estado do anúncio = do dono) |

A estrutura oficial está em `banco/banco.sql`.

## Como o pesquisar.php funciona (passo a passo)
1. Pega os filtros que vieram pela URL (`$_GET`).
2. Monta o SQL: cada filtro preenchido adiciona um `AND ... ?`,
   o tipo vai em `$tipos` (s, i, d) e o valor vai em `$valores`.
3. Conta quantos anúncios foram encontrados.
4. Calcula a paginação (12 por página).
5. Busca os anúncios da página atual.
6. Mostra o formulário e os cards.

## Filtros
Texto (palavra por palavra, no título e na descrição), categoria, preço mínimo/máximo,
estado, cidade e ordenação (recentes, antigos, menor e maior preço).
O banco oficial não tem status de anúncio, então anúncios vendidos ainda aparecem na pesquisa.

## Combinar com os outros grupos
- `imagem` do anúncio deve ser salva a partir da raiz do projeto (ex.: `assets/imagens/foto1.jpg`).
- Os cards abrem `detalhes.php?id=...` (pasta `anuncios/`).
- Para a busca aparecer no topo do site, o `header.php` deve incluir `barra_pesquisa.php`
  e o `assets/css/pesquisa.css`.

## Segurança
- `prepare()` + `bind_param()` com `?` evita SQL Injection.
- `htmlspecialchars()` evita que alguém injete HTML/JavaScript.
- A ordenação só aceita as opções da lista (if/elseif).
