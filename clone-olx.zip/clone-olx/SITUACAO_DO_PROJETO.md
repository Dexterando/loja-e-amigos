# Situação do projeto clone-olx

**Banco oficial: `banco/banco.sql`** (db_sitevendas). Para testar com dados: `banco/teste_db_sitevendas_mesclado.sql`.

## Funcionando (testado: pesquisa, login, perfil, publicar com foto, detalhes, favoritar, editar, excluir, meus anúncios)
| Arquivo | Classe? | Situação |
|---|---|---|
| `index.php` | — | ok (conteúdo da página inicial ainda vazio) |
| `includes/header.php` e `footer.php` | — | ok |
| `anuncios/pesquisar.php` + `Pesquisa.php` | sim (`Pesquisa`, usa também `Anuncio`) | ok |
| `anuncios/publicar.php`, `editar.php`, `excluir.php`, `listar.php`, `detalhes.php` | sim (`Anuncio`, `Favorito`, `Imagem`) | ok |
| `usuarios/cadastro.php` | **não** | ok (só usa a tabela `usuario`) |
| `usuarios/login.php` | **não** | ok |
| `usuarios/perfil.php` | **não** | ok (consultas corrigidas para o banco oficial) |

## Pendências do grupo de usuários
1. **O projeto exige classes**, e `cadastro.php`, `login.php` e `perfil.php` não usam nenhuma.
   Sugestão: uma classe `Usuario` em `usuarios/Usuario.php`, no mesmo estilo das outras.

## Ainda falta chegar
- conteúdo do `index.php`
- pasta `admin/`

## Correções feitas nesta versão (só onde havia erro)
| Arquivo | Erro | Correção |
|---|---|---|
| `anuncios/pesquisar.php` | conexão fechada antes do header (que usa o banco) → erro fatal, página não abria | `$conexao->close()` movido para depois do footer |
| `anuncios/pesquisar.php` | `style.css` não era carregado → header e footer sem estilo | 1 linha `<link>` do `style.css` |
| `includes/header.php` | caixa de busca com `action="#"` → não pesquisava | `action` apontando para `anuncios/pesquisar.php` |
| `usuarios/perfil.php` | usava as tabelas antigas (`anuncio`, `favorito`) → erro fatal depois do login | as 3 consultas passaram a usar `anuncios`, `favoritos`, `imagens` e `localizacao_cliente`, devolvendo as mesmas colunas na mesma ordem (o resto do arquivo não mudou). Como o banco oficial não tem status, todo anúncio aparece como "Ativo" |
| `anuncios/Imagem.php` (`validar`) | foto acima do limite do php.ini mostrava "Selecione uma imagem", mesmo com imagem escolhida | mensagem certa para cada caso: sem imagem, maior que 2 MB, ou outro erro de envio |
| `usuarios/cadastro.php`, `login.php`, `perfil.php` | logo renomeado para `logo.jpg` → imagem quebrada | caminho do logo atualizado |

Dados de teste (não é código):
- `banco/teste_db_sitevendas_mesclado.sql`: adicionadas localizações dos usuários e datas dos anúncios
  (sem isso o filtro de estado/cidade ficava vazio).
- `assets/imagens/teste/`: imagens dos 21 anúncios de teste (o SQL apontava para arquivos que não existiam).

## Regras combinadas (para as próximas páginas)
- **Conexão:** `include "../conexao.php";` — a senha do MySQL fica só nele.
- **Não fechar a conexão antes do `header.php`**: ele usa o banco para listar as categorias.
- **Páginas com header/footer** precisam ter o próprio `<!DOCTYPE html>`, `<head>` com
  `style.css` e `<body>` (o header não cria isso). Ver `index.php` ou `pesquisar.php`.
- **Preço:** `preco_centavos` (R$ 15,00 = 1500). Para mostrar: `number_format($preco / 100, 2, ',', '.')`.
- **Imagem:** cadastrar em `imagens` (caminho a partir da raiz, ex.: `assets/imagens/foto.jpg`)
  e guardar o `id_imagem` no anúncio.
- **Cidade/estado:** vêm de `localizacao_cliente` do dono do anúncio.
- **Acentos:** importar SQL em UTF-8 (`--default-character-set=utf8mb4`).
