<?php

require_once __DIR__ . "/Imagem.php";

class Anuncio
{
    private $conexao;
    private $imagem;

    public function __construct($conexao)
    {
        $this->conexao = $conexao;
        $this->imagem = new Imagem($conexao);
    }

    public function usuarioEhVendedor($idUsuario)
    {
        $consulta = $this->conexao->prepare(
            "SELECT vendedor FROM usuario WHERE id_usuario = ?"
        );

        $consulta->bind_param("i", $idUsuario);
        $consulta->execute();
        $consulta->bind_result($vendedor);

        $ehVendedor = false;

        if ($consulta->fetch()) {
            if ($vendedor == 1) {
                $ehVendedor = true;
            }
        }

        $consulta->close();

        return $ehVendedor;
    }

    public function temLocalizacao($idDono)
    {
        $consulta = $this->conexao->prepare(
            "SELECT id_localizacao FROM localizacao_cliente WHERE id_dono = ? LIMIT 1"
        );

        $consulta->bind_param("i", $idDono);
        $consulta->execute();
        $consulta->store_result();

        $tem = false;

        if ($consulta->num_rows > 0) {
            $tem = true;
        }

        $consulta->close();

        return $tem;
    }

    public function listarCategorias()
    {
        $categorias = array();

        $resultado = $this->conexao->query(
            "SELECT id_categoria, nome_categoria FROM categoria ORDER BY nome_categoria ASC"
        );

        while ($linha = $resultado->fetch_assoc()) {
            $categorias[] = $linha;
        }

        return $categorias;
    }

    public function categoriaExiste($idCategoria)
    {
        $consulta = $this->conexao->prepare(
            "SELECT id_categoria FROM categoria WHERE id_categoria = ?"
        );

        $consulta->bind_param("i", $idCategoria);
        $consulta->execute();
        $consulta->store_result();

        $existe = false;

        if ($consulta->num_rows > 0) {
            $existe = true;
        }

        $consulta->close();

        return $existe;
    }

    public function buscarPorId($idAnuncio)
    {
        $consulta = $this->conexao->prepare(
            "SELECT a.id_anuncio, a.id_dono, a.nome_anuncio, a.descricao_anuncio,
                    a.preco_centavos, a.criado_em, a.id_categoria, a.id_imagem,
                    c.nome_categoria, i.caminho_imagem,
                    u.nome_user, u.criado_em AS membro_desde,
                    lc.cidade, lc.estado
            FROM anuncios a
            INNER JOIN usuario u ON u.id_usuario = a.id_dono
            LEFT JOIN categoria c ON c.id_categoria = a.id_categoria
            LEFT JOIN imagens i ON i.id_imagem = a.id_imagem
            LEFT JOIN localizacao_cliente lc ON lc.id_localizacao = (
                SELECT MAX(l2.id_localizacao)
                FROM localizacao_cliente l2
                WHERE l2.id_dono = a.id_dono
            )
            WHERE a.id_anuncio = ?"
        );

        $consulta->bind_param("i", $idAnuncio);
        $consulta->execute();

        $dados = $consulta->get_result()->fetch_assoc();

        $consulta->close();

        return $dados;
    }

    public function listarDoDono($idDono)
    {
        $lista = array();

        $consulta = $this->conexao->prepare(
            "SELECT a.id_anuncio, a.nome_anuncio, a.preco_centavos, a.criado_em,
                    c.nome_categoria, i.caminho_imagem
            FROM anuncios a
            LEFT JOIN categoria c ON c.id_categoria = a.id_categoria
            LEFT JOIN imagens i ON i.id_imagem = a.id_imagem
            WHERE a.id_dono = ?
            ORDER BY a.criado_em DESC"
        );

        $consulta->bind_param("i", $idDono);
        $consulta->execute();

        $resultado = $consulta->get_result();

        while ($linha = $resultado->fetch_assoc()) {
            $lista[] = $linha;
        }

        $consulta->close();

        return $lista;
    }

    public function listarRelacionados($idCategoria, $idAnuncio)
    {
        $lista = array();

        $consulta = $this->conexao->prepare(
            "SELECT a.id_anuncio, a.nome_anuncio, a.preco_centavos, i.caminho_imagem
            FROM anuncios a
            LEFT JOIN imagens i ON i.id_imagem = a.id_imagem
            WHERE a.id_categoria = ? AND a.id_anuncio <> ?
            ORDER BY a.criado_em DESC
            LIMIT 4"
        );

        $consulta->bind_param("ii", $idCategoria, $idAnuncio);
        $consulta->execute();

        $resultado = $consulta->get_result();

        while ($linha = $resultado->fetch_assoc()) {
            $lista[] = $linha;
        }

        $consulta->close();

        return $lista;
    }

    public function contarPedidos($idAnuncio)
    {
        $consulta = $this->conexao->prepare(
            "SELECT COUNT(*) FROM pedido WHERE id_anuncio = ?"
        );

        $consulta->bind_param("i", $idAnuncio);
        $consulta->execute();
        $consulta->bind_result($total);
        $consulta->fetch();
        $consulta->close();

        return $total;
    }

    public function publicar($idDono, $titulo, $descricao, $idCategoria, $precoCentavos, $caminhoImagem, $local)
    {
        $this->conexao->begin_transaction();

        $sucesso = true;
        $idAnuncio = 0;

        $idImagem = $this->imagem->inserir($caminhoImagem);

        if ($idImagem == 0) {
            $sucesso = false;
        }

        if ($sucesso == true && $local != null) {

            $insercaoLocal = $this->conexao->prepare(
                "INSERT INTO localizacao_cliente
                (id_dono, cidade, estado, rua, cep, numero, complemento)
                VALUES (?, ?, ?, ?, ?, ?, ?)"
            );

            $insercaoLocal->bind_param(
                "issssss",
                $idDono,
                $local["cidade"],
                $local["estado"],
                $local["rua"],
                $local["cep"],
                $local["numero"],
                $local["complemento"]
            );

            if ($insercaoLocal->execute() == false) {
                $sucesso = false;
            }

            $insercaoLocal->close();
        }

        if ($sucesso == true) {

            $insercaoAnuncio = $this->conexao->prepare(
                "INSERT INTO anuncios
                (id_dono, nome_anuncio, descricao_anuncio, id_imagem, id_categoria, preco_centavos)
                VALUES (?, ?, ?, ?, ?, ?)"
            );

            $insercaoAnuncio->bind_param(
                "issiii",
                $idDono,
                $titulo,
                $descricao,
                $idImagem,
                $idCategoria,
                $precoCentavos
            );

            if ($insercaoAnuncio->execute()) {
                $idAnuncio = $this->conexao->insert_id;
            } else {
                $sucesso = false;
            }

            $insercaoAnuncio->close();
        }

        if ($sucesso == true) {
            $this->conexao->commit();
            return $idAnuncio;
        }

        $this->conexao->rollback();

        return 0;
    }

    public function editar($idAnuncio, $idDono, $titulo, $descricao, $idCategoria, $precoCentavos, $caminhoImagem)
    {
        $dados = $this->buscarPorId($idAnuncio);

        if ($dados == null) {
            return false;
        }

        if ($dados["id_dono"] != $idDono) {
            return false;
        }

        $idImagemAntiga = (int) $dados["id_imagem"];
        $idImagem = $idImagemAntiga;

        $this->conexao->begin_transaction();

        $sucesso = true;

        if ($caminhoImagem != "") {

            $idImagem = $this->imagem->inserir($caminhoImagem);

            if ($idImagem == 0) {
                $sucesso = false;
            }
        }

        if ($sucesso == true) {

            $atualizacao = $this->conexao->prepare(
                "UPDATE anuncios
                SET nome_anuncio = ?, descricao_anuncio = ?, id_categoria = ?,
                    preco_centavos = ?, id_imagem = ?
                WHERE id_anuncio = ? AND id_dono = ?"
            );

            $atualizacao->bind_param(
                "ssiiiii",
                $titulo,
                $descricao,
                $idCategoria,
                $precoCentavos,
                $idImagem,
                $idAnuncio,
                $idDono
            );

            if ($atualizacao->execute() == false) {
                $sucesso = false;
            }

            $atualizacao->close();
        }

        if ($sucesso == true) {

            $this->conexao->commit();

            if ($caminhoImagem != "") {
                $this->imagem->removerSeNaoUsada($idImagemAntiga);
            }

            return true;
        }

        $this->conexao->rollback();

        return false;
    }

    public function excluir($idAnuncio, $idDono)
    {
        $dados = $this->buscarPorId($idAnuncio);

        if ($dados == null) {
            return "Anuncio nao encontrado.";
        }

        if ($dados["id_dono"] != $idDono) {
            return "Voce nao tem permissao para excluir este anuncio.";
        }

        if ($this->contarPedidos($idAnuncio) > 0) {
            return "Este anuncio possui pedidos e nao pode ser excluido.";
        }

        $this->conexao->begin_transaction();

        $sucesso = true;

        $remocaoFavoritos = $this->conexao->prepare(
            "DELETE FROM favoritos WHERE id_anuncio = ?"
        );

        $remocaoFavoritos->bind_param("i", $idAnuncio);

        if ($remocaoFavoritos->execute() == false) {
            $sucesso = false;
        }

        $remocaoFavoritos->close();

        if ($sucesso == true) {

            $remocaoAnuncio = $this->conexao->prepare(
                "DELETE FROM anuncios WHERE id_anuncio = ? AND id_dono = ?"
            );

            $remocaoAnuncio->bind_param("ii", $idAnuncio, $idDono);

            if ($remocaoAnuncio->execute() == false) {
                $sucesso = false;
            }

            $remocaoAnuncio->close();
        }

        if ($sucesso == true) {

            $this->conexao->commit();

            $this->imagem->removerSeNaoUsada((int) $dados["id_imagem"]);

            return "";
        }

        $this->conexao->rollback();

        return "Erro ao excluir o anuncio.";
    }
}
