<?php

class Favorito
{
    private $conexao;

    public function __construct($conexao)
    {
        $this->conexao = $conexao;
    }

    public function existe($idDono, $idAnuncio)
    {
        $consulta = $this->conexao->prepare(
            "SELECT id_favorito FROM favoritos WHERE id_dono = ? AND id_anuncio = ?"
        );

        $consulta->bind_param("ii", $idDono, $idAnuncio);
        $consulta->execute();
        $consulta->store_result();

        $existe = false;

        if ($consulta->num_rows > 0) {
            $existe = true;
        }

        $consulta->close();

        return $existe;
    }

    public function adicionar($idDono, $idAnuncio)
    {
        if ($this->existe($idDono, $idAnuncio) == true) {
            return;
        }

        $insercao = $this->conexao->prepare(
            "INSERT INTO favoritos (id_dono, id_anuncio) VALUES (?, ?)"
        );

        $insercao->bind_param("ii", $idDono, $idAnuncio);
        $insercao->execute();
        $insercao->close();
    }

    public function remover($idDono, $idAnuncio)
    {
        $remocao = $this->conexao->prepare(
            "DELETE FROM favoritos WHERE id_dono = ? AND id_anuncio = ?"
        );

        $remocao->bind_param("ii", $idDono, $idAnuncio);
        $remocao->execute();
        $remocao->close();
    }

    public function contar($idAnuncio)
    {
        $consulta = $this->conexao->prepare(
            "SELECT COUNT(*) FROM favoritos WHERE id_anuncio = ?"
        );

        $consulta->bind_param("i", $idAnuncio);
        $consulta->execute();
        $consulta->bind_result($total);
        $consulta->fetch();
        $consulta->close();

        return $total;
    }
}
