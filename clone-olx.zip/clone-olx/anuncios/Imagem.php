<?php

class Imagem
{
    private $conexao;
    private $pasta;
    private $pastaBanco = "assets/imagens/anuncios/";

    public function __construct($conexao)
    {
        $this->conexao = $conexao;
        $this->pasta = __DIR__ . "/../assets/imagens/anuncios/";
    }

    public function validar($arquivo)
    {
        if ($arquivo == null || $arquivo["error"] == UPLOAD_ERR_NO_FILE) {
            return "Selecione uma imagem para o anuncio.";
        }

        // Arquivo maior que o limite do php.ini: o PHP nem chega a entregar a imagem
        if ($arquivo["error"] == UPLOAD_ERR_INI_SIZE || $arquivo["error"] == UPLOAD_ERR_FORM_SIZE) {
            return "A imagem deve ter no maximo 2 MB.";
        }

        if ($arquivo["error"] != UPLOAD_ERR_OK) {
            return "Erro ao enviar a imagem. Tente novamente.";
        }

        $extensao = strtolower(pathinfo($arquivo["name"], PATHINFO_EXTENSION));

        if ($arquivo["size"] > 2 * 1024 * 1024) {
            return "A imagem deve ter no maximo 2 MB.";
        }

        if (in_array($extensao, array("jpg", "jpeg", "png", "webp")) == false) {
            return "A imagem deve ser JPG, PNG ou WEBP.";
        }

        if (getimagesize($arquivo["tmp_name"]) == false) {
            return "O arquivo enviado nao e uma imagem valida.";
        }

        return "";
    }

    public function salvarArquivo($arquivo)
    {
        if (is_dir($this->pasta) == false) {
            mkdir($this->pasta, 0777, true);
        }

        $extensao = strtolower(pathinfo($arquivo["name"], PATHINFO_EXTENSION));
        $nomeArquivo = "anuncio_" . bin2hex(random_bytes(8)) . "." . $extensao;

        if (move_uploaded_file($arquivo["tmp_name"], $this->pasta . $nomeArquivo)) {
            return $this->pastaBanco . $nomeArquivo;
        }

        return "";
    }

    public function apagarArquivo($caminhoBanco)
    {
        if (strpos($caminhoBanco, $this->pastaBanco) === 0) {

            $caminhoCompleto = __DIR__ . "/../" . $caminhoBanco;

            if (is_file($caminhoCompleto)) {
                unlink($caminhoCompleto);
            }
        }
    }

    public function inserir($caminhoBanco)
    {
        $idImagem = 0;

        $insercao = $this->conexao->prepare(
            "INSERT INTO imagens (caminho_imagem) VALUES (?)"
        );

        $insercao->bind_param("s", $caminhoBanco);

        if ($insercao->execute()) {
            $idImagem = $this->conexao->insert_id;
        }

        $insercao->close();

        return $idImagem;
    }

    public function removerSeNaoUsada($idImagem)
    {
        $consulta = $this->conexao->prepare(
            "SELECT caminho_imagem FROM imagens WHERE id_imagem = ?"
        );

        $consulta->bind_param("i", $idImagem);
        $consulta->execute();
        $consulta->bind_result($caminhoBanco);

        if ($consulta->fetch() == false) {
            $consulta->close();
            return;
        }

        $consulta->close();

        $consultaUso = $this->conexao->prepare(
            "SELECT COUNT(*) FROM anuncios WHERE id_imagem = ?"
        );

        $consultaUso->bind_param("i", $idImagem);
        $consultaUso->execute();
        $consultaUso->bind_result($totalUso);
        $consultaUso->fetch();
        $consultaUso->close();

        if ($totalUso == 0) {

            $remocao = $this->conexao->prepare(
                "DELETE FROM imagens WHERE id_imagem = ?"
            );

            $remocao->bind_param("i", $idImagem);
            $remocao->execute();
            $remocao->close();

            $this->apagarArquivo($caminhoBanco);
        }
    }
}
