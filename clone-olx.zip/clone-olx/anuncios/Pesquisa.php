<?php
// =====================================================
// anuncios/Pesquisa.php
// Classe responsável pela pesquisa e pelos filtros de anúncios
// Banco: db_sitevendas (tabelas anuncios, categoria, imagens e localizacao_cliente)
// =====================================================

class Pesquisa
{
    private $conexao;
    private $porPagina = 12;

    // Partes do SQL montadas a partir dos filtros
    private $condicoes;   // texto do WHERE, com "?" no lugar dos valores
    private $tipos;       // tipo de cada valor: s = texto, i = inteiro
    private $valores;     // valores, na mesma ordem dos "?"

    public function __construct($conexao)
    {
        $this->conexao = $conexao;
    }

    // -------------------------------------------------
    // 1) LER OS FILTROS QUE VIERAM PELA URL ($_GET)
    // -------------------------------------------------
    public function lerFiltros($get)
    {
        $filtros = array();

        $filtros["busca"]     = isset($get["busca"])     ? trim($get["busca"])     : "";
        $filtros["categoria"] = isset($get["categoria"]) ? (int) $get["categoria"] : 0;
        $filtros["preco_min"] = isset($get["preco_min"]) ? $get["preco_min"]       : "";
        $filtros["preco_max"] = isset($get["preco_max"]) ? $get["preco_max"]       : "";
        $filtros["estado"]    = isset($get["estado"])    ? $get["estado"]          : "";
        $filtros["cidade"]    = isset($get["cidade"])    ? trim($get["cidade"])    : "";
        $filtros["ordem"]     = isset($get["ordem"])     ? $get["ordem"]           : "recentes";
        $filtros["pagina"]    = isset($get["pagina"])    ? (int) $get["pagina"]    : 1;

        if ($filtros["pagina"] < 1) {
            $filtros["pagina"] = 1;
        }

        // Ordenação desconhecida vira "recentes"
        if (in_array($filtros["ordem"], array("recentes", "antigos", "menor_preco", "maior_preco")) == false) {
            $filtros["ordem"] = "recentes";
        }

        return $filtros;
    }

    // -------------------------------------------------
    // 2) MONTAR O WHERE DE ACORDO COM OS FILTROS
    //    Cada filtro preenchido adiciona uma condição com "?".
    // -------------------------------------------------
    private function montarCondicoes($filtros)
    {
        $this->condicoes = "WHERE 1=1";
        $this->tipos     = "";
        $this->valores   = array();

        // Filtro de texto (palavra por palavra, no nome ou na descrição)
        if ($filtros["busca"] != "") {
            $palavras = explode(" ", $filtros["busca"]);   // "iphone 13 azul" vira ["iphone", "13", "azul"]

            foreach ($palavras as $palavra) {
                if ($palavra != "") {                       // ignora espaços duplos
                    $this->condicoes .= " AND (a.nome_anuncio LIKE ? OR a.descricao_anuncio LIKE ?)";
                    $this->tipos     .= "ss";
                    $this->valores[]  = "%$palavra%";
                    $this->valores[]  = "%$palavra%";
                }
            }
        }

        // Filtro de categoria
        if ($filtros["categoria"] > 0) {
            $this->condicoes .= " AND a.id_categoria = ?";
            $this->tipos     .= "i";
            $this->valores[]  = $filtros["categoria"];
        }

        // Filtro de preço mínimo (digitado em reais, o banco guarda em centavos)
        if ($filtros["preco_min"] != "") {
            $this->condicoes .= " AND a.preco_centavos >= ?";
            $this->tipos     .= "i";
            $this->valores[]  = (int) round((float) $filtros["preco_min"] * 100);
        }

        // Filtro de preço máximo
        if ($filtros["preco_max"] != "") {
            $this->condicoes .= " AND a.preco_centavos <= ?";
            $this->tipos     .= "i";
            $this->valores[]  = (int) round((float) $filtros["preco_max"] * 100);
        }

        // Filtro de estado (UF): vem do endereço do dono do anúncio
        if ($filtros["estado"] != "") {
            $this->condicoes .= " AND EXISTS (SELECT 1 FROM localizacao_cliente lf WHERE lf.id_dono = a.id_dono AND lf.estado = ?)";
            $this->tipos     .= "s";
            $this->valores[]  = $filtros["estado"];
        }

        // Filtro de cidade
        if ($filtros["cidade"] != "") {
            $this->condicoes .= " AND EXISTS (SELECT 1 FROM localizacao_cliente lc_filtro WHERE lc_filtro.id_dono = a.id_dono AND lc_filtro.cidade LIKE ?)";
            $this->tipos     .= "s";
            $this->valores[]  = "%" . $filtros["cidade"] . "%";
        }
    }

    // -------------------------------------------------
    // 3) ORDENAÇÃO (só aceitamos estas opções)
    // -------------------------------------------------
    private function ordenacao($ordem)
    {
        if ($ordem == "menor_preco") {
            return "a.preco_centavos ASC";
        } elseif ($ordem == "maior_preco") {
            return "a.preco_centavos DESC";
        } elseif ($ordem == "antigos") {
            return "a.criado_em ASC";
        }

        return "a.criado_em DESC";   // padrão: mais recentes
    }

    // -------------------------------------------------
    // 4) CONTAR QUANTOS ANÚNCIOS FORAM ENCONTRADOS
    // -------------------------------------------------
    private function contar()
    {
        $consulta = $this->conexao->prepare("SELECT COUNT(*) AS total FROM anuncios a " . $this->condicoes);

        if ($this->tipos != "") {
            $consulta->bind_param($this->tipos, ...$this->valores);   // "..." passa cada valor do array separado
        }

        $consulta->execute();
        $linha = $consulta->get_result()->fetch_assoc();
        $consulta->close();

        return (int) $linha["total"];
    }

    // -------------------------------------------------
    // 5) FAZER A PESQUISA
    //    Devolve os anúncios da página atual + total e páginas
    // -------------------------------------------------
    public function buscar($filtros)
    {
        $this->montarCondicoes($filtros);

        // Paginação
        $total = $this->contar();

        $totalPaginas = ceil($total / $this->porPagina);
        if ($totalPaginas < 1) {
            $totalPaginas = 1;
        }

        $pagina = $filtros["pagina"];
        if ($pagina > $totalPaginas) {
            $pagina = $totalPaginas;
        }

        $inicio = ($pagina - 1) * $this->porPagina;

        // Anúncios da página atual
        $sql = "SELECT a.id_anuncio,
                       a.nome_anuncio AS titulo,
                       a.descricao_anuncio AS descricao,
                       a.preco_centavos AS preco,
                       lc.cidade,
                       lc.estado,
                       i.caminho_imagem AS imagem,
                       a.criado_em AS data_publicacao,
                       c.nome_categoria
                FROM anuncios a
                LEFT JOIN categoria c ON c.id_categoria = a.id_categoria
                LEFT JOIN imagens i ON i.id_imagem = a.id_imagem
                LEFT JOIN localizacao_cliente lc ON lc.id_localizacao = (
                    SELECT MAX(l2.id_localizacao)
                    FROM localizacao_cliente l2
                    WHERE l2.id_dono = a.id_dono
                )
                " . $this->condicoes . "
                ORDER BY " . $this->ordenacao($filtros["ordem"]) . "
                LIMIT " . $this->porPagina . " OFFSET " . $inicio;

        $consulta = $this->conexao->prepare($sql);

        if ($this->tipos != "") {
            $consulta->bind_param($this->tipos, ...$this->valores);
        }

        $consulta->execute();
        $resultado = $consulta->get_result();

        $anuncios = array();
        while ($linha = $resultado->fetch_assoc()) {
            $anuncios[] = $linha;
        }

        $consulta->close();

        return array(
            "anuncios"      => $anuncios,
            "total"         => $total,
            "total_paginas" => $totalPaginas,
            "pagina"        => $pagina
        );
    }

    // -------------------------------------------------
    // 6) ESTADOS PARA O FILTRO (só os que existem no banco)
    // -------------------------------------------------
    public function listarEstados()
    {
        $estados = array();

        $resultado = $this->conexao->query(
            "SELECT DISTINCT estado FROM localizacao_cliente WHERE estado IS NOT NULL AND estado <> '' ORDER BY estado"
        );

        while ($linha = $resultado->fetch_assoc()) {
            $estados[] = $linha;
        }

        return $estados;
    }
}
