<?php

session_start();

include "../conexao.php";
require_once "Anuncio.php";
require_once "Favorito.php";

$anuncio = new Anuncio($conexao);
$favorito = new Favorito($conexao);

if (!isset($_SESSION["token"])) {
    $_SESSION["token"] = bin2hex(random_bytes(32));
}

$idAnuncio = 0;

if (isset($_GET["id"])) {
    $idAnuncio = (int) $_GET["id"];
}

$logado = false;
$idLogado = 0;

if (isset($_SESSION["id_usuario"])) {
    $logado = true;
    $idLogado = (int) $_SESSION["id_usuario"];
}

$mensagem = "";

if (isset($_GET["publicado"])) {
    $mensagem = "Anuncio publicado com sucesso!";
}

if (isset($_GET["editado"])) {
    $mensagem = "Anuncio atualizado com sucesso!";
}

if (isset($_GET["favorito"])) {
    if ($_GET["favorito"] == "1") {
        $mensagem = "Anuncio adicionado aos favoritos.";
    } else {
        $mensagem = "Anuncio removido dos favoritos.";
    }
}

$dados = $anuncio->buscarPorId($idAnuncio);

if ($dados == null) {
    http_response_code(404);
}

if ($dados != null && $_SERVER["REQUEST_METHOD"] == "POST") {

    $tokenEnviado = "";

    if (isset($_POST["token"])) {
        $tokenEnviado = $_POST["token"];
    }

    $acao = "";

    if (isset($_POST["acao"])) {
        $acao = $_POST["acao"];
    }

    if ($logado == false) {

        $conexao->close();

        header("Location: ../usuarios/login.php");
        exit;
    }

    if (hash_equals($_SESSION["token"], $tokenEnviado) == false) {

        $mensagem = "Requisicao invalida. Tente novamente.";

    } elseif ($acao == "favoritar") {

        $favorito->adicionar($idLogado, $idAnuncio);

        $conexao->close();

        header("Location: detalhes.php?id=" . $idAnuncio . "&favorito=1");
        exit;

    } elseif ($acao == "desfavoritar") {

        $favorito->remover($idLogado, $idAnuncio);

        $conexao->close();

        header("Location: detalhes.php?id=" . $idAnuncio . "&favorito=0");
        exit;
    }
}

$favoritado = false;
$totalFavoritos = 0;
$relacionados = array();

if ($dados != null) {

    if ($logado == true) {
        $favoritado = $favorito->existe($idLogado, $idAnuncio);
    }

    $totalFavoritos = $favorito->contar($idAnuncio);
    $relacionados = $anuncio->listarRelacionados((int) $dados["id_categoria"], $idAnuncio);
}

$tituloPagina = "Anuncio nao encontrado";

if ($dados != null) {
    $tituloPagina = $dados["nome_anuncio"];
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo htmlspecialchars($tituloPagina, ENT_QUOTES, "UTF-8"); ?> - Loja e Amigos</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/pesquisa.css">
    <link rel="stylesheet" href="../assets/css/anuncios.css">

</head>

<body>

    <?php include "../includes/header.php"; ?>

    <main class="pagina-anuncio pagina-larga">

        <?php

        if ($mensagem != "") {

            echo "<div class='mensagem'>";
            echo htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8");
            echo "</div>";

        }

        if ($dados == null) {

            echo "<div class='vazio'>";
            echo "<p>Este anúncio não existe ou foi removido.</p>";
            echo "<a class='botao' href='pesquisar.php'>Ver outros anúncios</a>";
            echo "</div>";

        } else {

            $precoFormatado = number_format($dados["preco_centavos"] / 100, 2, ",", ".");
            $dataFormatada = date("d/m/Y", strtotime($dados["criado_em"]));
            $membroDesde = date("m/Y", strtotime($dados["membro_desde"]));

            $local = "Local não informado";

            if ($dados["cidade"] != "") {
                $local = $dados["cidade"] . " - " . $dados["estado"];
            }

            $ehDono = false;

            if ($logado == true && $idLogado == (int) $dados["id_dono"]) {
                $ehDono = true;
            }

        ?>

        <div class="caminho">

            <a href="../index.php">Início</a>
            &rsaquo;
            <a href="pesquisar.php?categoria=<?php echo (int) $dados["id_categoria"]; ?>">
                <?php echo htmlspecialchars($dados["nome_categoria"], ENT_QUOTES, "UTF-8"); ?>
            </a>

        </div>

        <div class="detalhes">

            <div class="detalhes-imagem">

                <?php

                if ($dados["caminho_imagem"] != "") {
                    echo "<img src='../" . htmlspecialchars($dados["caminho_imagem"], ENT_QUOTES, "UTF-8") . "' alt='" . htmlspecialchars($dados["nome_anuncio"], ENT_QUOTES, "UTF-8") . "'>";
                } else {
                    echo "<div class='sem-imagem'>Sem imagem</div>";
                }

                ?>

            </div>

            <div class="detalhes-info">

                <div class="caixa">

                    <h1><?php echo htmlspecialchars($dados["nome_anuncio"], ENT_QUOTES, "UTF-8"); ?></h1>

                    <div class="detalhes-preco">R$ <?php echo $precoFormatado; ?></div>

                    <div class="detalhes-meta">
                        <?php echo htmlspecialchars($local, ENT_QUOTES, "UTF-8"); ?>
                        &middot; Publicado em <?php echo $dataFormatada; ?>
                    </div>

                    <div class="detalhes-meta">
                        <?php echo (int) $totalFavoritos; ?> pessoa(s) favoritaram este anúncio
                    </div>

                    <?php

                    if ($ehDono) {

                        echo "<div class='etiqueta'>Este é o seu anúncio</div>";

                        echo "<div class='acoes'>";
                        echo "<a class='botao botao-contorno botao-pequeno' href='editar.php?id=" . (int) $dados["id_anuncio"] . "'>Editar</a>";
                        echo "<a class='botao botao-perigo botao-pequeno' href='excluir.php?id=" . (int) $dados["id_anuncio"] . "'>Excluir</a>";
                        echo "</div>";

                    } else {

                        $acaoFavorito = "favoritar";
                        $textoFavorito = "Adicionar aos favoritos";
                        $classeFavorito = "botao botao-largo";

                        if ($favoritado) {
                            $acaoFavorito = "desfavoritar";
                            $textoFavorito = "Remover dos favoritos";
                            $classeFavorito = "botao botao-largo botao-contorno";
                        }

                        echo "<form method='POST' action='detalhes.php?id=" . (int) $dados["id_anuncio"] . "'>";
                        echo "<input type='hidden' name='token' value='" . htmlspecialchars($_SESSION["token"], ENT_QUOTES, "UTF-8") . "'>";
                        echo "<input type='hidden' name='acao' value='" . $acaoFavorito . "'>";
                        echo "<button type='submit' class='" . $classeFavorito . "'>" . $textoFavorito . "</button>";
                        echo "</form>";
                    }

                    ?>

                </div>

                <div class="caixa">

                    <h2>Vendedor</h2>

                    <div class="vendedor">

                        <div class="avatar">
                            <?php echo htmlspecialchars(mb_strtoupper(mb_substr($dados["nome_user"], 0, 1, "UTF-8"), "UTF-8"), ENT_QUOTES, "UTF-8"); ?>
                        </div>

                        <div>

                            <div class="vendedor-nome">
                                <?php echo htmlspecialchars($dados["nome_user"], ENT_QUOTES, "UTF-8"); ?>
                            </div>

                            <div class="detalhes-meta">
                                Membro desde <?php echo $membroDesde; ?>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="caixa">

            <h2>Descrição</h2>

            <p class="descricao">
                <?php echo nl2br(htmlspecialchars($dados["descricao_anuncio"], ENT_QUOTES, "UTF-8")); ?>
            </p>

        </div>

        <?php

        if (count($relacionados) > 0) {

            echo "<div class='caixa'>";
            echo "<h2>Outros anúncios da categoria</h2>";
            echo "<div class='grade'>";

            foreach ($relacionados as $relacionado) {

                $precoRelacionado = number_format($relacionado["preco_centavos"] / 100, 2, ",", ".");

                echo "<a class='card' href='detalhes.php?id=" . (int) $relacionado["id_anuncio"] . "'>";

                echo "<div class='foto'>";

                if ($relacionado["caminho_imagem"] != "") {
                    echo "<img src='../" . htmlspecialchars($relacionado["caminho_imagem"], ENT_QUOTES, "UTF-8") . "' alt=''>";
                } else {
                    echo "Sem foto";
                }

                echo "</div>";

                echo "<div class='info'>";
                echo "<h3>" . htmlspecialchars($relacionado["nome_anuncio"], ENT_QUOTES, "UTF-8") . "</h3>";
                echo "<p class='preco'>R$ " . $precoRelacionado . "</p>";
                echo "</div>";

                echo "</a>";
            }

            echo "</div>";
            echo "</div>";
        }

        }

        ?>

    </main>

    <?php include "../includes/footer.php"; ?>

</body>

</html>

<?php $conexao->close(); ?>
