<?php

session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: ../usuarios/login.php");
    exit;
}

$idLogado = (int) $_SESSION["id_usuario"];

if (!isset($_SESSION["token"])) {
    $_SESSION["token"] = bin2hex(random_bytes(32));
}

include "../conexao.php";
require_once "Anuncio.php";

$anuncio = new Anuncio($conexao);
$imagem = new Imagem($conexao);

$idAnuncio = 0;

if (isset($_GET["id"])) {
    $idAnuncio = (int) $_GET["id"];
}

$mensagem = "";
$titulo = "";
$descricao = "";
$preco = "";
$idCategoria = 0;
$caminhoAtual = "";
$podeEditar = false;

$dados = $anuncio->buscarPorId($idAnuncio);

if ($dados == null) {

    http_response_code(404);
    $mensagem = "Este anuncio nao existe ou foi removido.";

} elseif ($dados["id_dono"] != $idLogado) {

    http_response_code(403);
    $mensagem = "Voce nao tem permissao para editar este anuncio.";

} else {

    $podeEditar = true;

    $titulo = $dados["nome_anuncio"];
    $descricao = $dados["descricao_anuncio"];
    $preco = number_format($dados["preco_centavos"] / 100, 2, ".", "");
    $idCategoria = (int) $dados["id_categoria"];
    $caminhoAtual = $dados["caminho_imagem"];
}

$categorias = $anuncio->listarCategorias();

if ($_SERVER["REQUEST_METHOD"] == "POST" && $podeEditar == true) {

    $tokenEnviado = "";

    if (isset($_POST["token"])) {
        $tokenEnviado = $_POST["token"];
    }

    $titulo = trim($_POST["titulo"]);
    $descricao = trim($_POST["descricao"]);
    $preco = trim($_POST["preco"]);

    if (isset($_POST["categoria"])) {
        $idCategoria = (int) $_POST["categoria"];
    }

    $precoCentavos = 0;

    if (is_numeric($preco)) {
        $precoCentavos = (int) round((float) $preco * 100);
    }

    $arquivo = null;
    $trocarImagem = false;

    if (isset($_FILES["imagem"])) {
        if ($_FILES["imagem"]["error"] != UPLOAD_ERR_NO_FILE) {
            $arquivo = $_FILES["imagem"];
            $trocarImagem = true;
        }
    }

    $mensagemImagem = "";

    if ($trocarImagem == true) {
        $mensagemImagem = $imagem->validar($arquivo);
    }

    if (hash_equals($_SESSION["token"], $tokenEnviado) == false) {

        $mensagem = "Requisicao invalida. Tente novamente.";

    } elseif ($titulo == "" || $descricao == "" || $preco == "") {

        $mensagem = "Preencha todos os campos.";

    } elseif (mb_strlen($titulo, "UTF-8") > 256) {

        $mensagem = "O titulo deve ter no maximo 256 caracteres.";

    } elseif ($precoCentavos <= 0 || $precoCentavos > 999999999) {

        $mensagem = "Digite um preco valido.";

    } elseif ($anuncio->categoriaExiste($idCategoria) == false) {

        $mensagem = "Escolha uma categoria.";

    } elseif ($mensagemImagem != "") {

        $mensagem = $mensagemImagem;

    } else {

        $caminhoBanco = "";

        if ($trocarImagem == true) {
            $caminhoBanco = $imagem->salvarArquivo($arquivo);
        }

        if ($trocarImagem == true && $caminhoBanco == "") {

            $mensagem = "Erro ao salvar a imagem.";

        } else {

            $editou = $anuncio->editar(
                $idAnuncio,
                $idLogado,
                $titulo,
                $descricao,
                $idCategoria,
                $precoCentavos,
                $caminhoBanco
            );

            if ($editou == true) {

                $conexao->close();

                header("Location: detalhes.php?id=" . $idAnuncio . "&editado=1");
                exit;

            } else {

                if ($caminhoBanco != "") {
                    $imagem->apagarArquivo($caminhoBanco);
                }

                $mensagem = "Erro ao salvar as alteracoes.";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Editar anuncio - Loja e Amigos</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/anuncios.css">

</head>

<body>

    <?php include "../includes/header.php"; ?>

    <main class="pagina-anuncio">

        <div class="caixa">

            <h1>Editar anúncio</h1>

            <?php

            if ($mensagem != "") {

                echo "<div class='mensagem'>";
                echo htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8");
                echo "</div>";

            }

            if ($podeEditar == false) {

                echo "<div class='vazio'>";
                echo "<a class='botao' href='listar.php'>Meus anúncios</a>";
                echo "</div>";

            } else {

            ?>

            <form method="POST" action="" enctype="multipart/form-data">

                <input
                    type="hidden"
                    name="token"
                    value="<?php echo htmlspecialchars($_SESSION["token"], ENT_QUOTES, "UTF-8"); ?>"
                >

                <div class="campo">

                    <label for="titulo">Título do anúncio</label>

                    <input
                        type="text"
                        name="titulo"
                        id="titulo"
                        maxlength="256"
                        value="<?php echo htmlspecialchars($titulo, ENT_QUOTES, "UTF-8"); ?>"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="categoria">Categoria</label>

                    <select name="categoria" id="categoria" required>

                        <option value="">Selecione</option>

                        <?php

                        foreach ($categorias as $categoriaLista) {

                            $selecionada = "";

                            if ($categoriaLista["id_categoria"] == $idCategoria) {
                                $selecionada = "selected";
                            }

                            echo "<option value='" . (int) $categoriaLista["id_categoria"] . "' " . $selecionada . ">";
                            echo htmlspecialchars($categoriaLista["nome_categoria"], ENT_QUOTES, "UTF-8");
                            echo "</option>";
                        }

                        ?>

                    </select>

                </div>

                <div class="campo">

                    <label for="preco">Preço (R$)</label>

                    <input
                        type="number"
                        name="preco"
                        id="preco"
                        min="0.01"
                        step="0.01"
                        value="<?php echo htmlspecialchars($preco, ENT_QUOTES, "UTF-8"); ?>"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="descricao">Descrição</label>

                    <textarea
                        name="descricao"
                        id="descricao"
                        rows="6"
                        required
                    ><?php echo htmlspecialchars($descricao, ENT_QUOTES, "UTF-8"); ?></textarea>

                </div>

                <div class="campo">

                    <label>Imagem atual</label>

                    <?php

                    if ($caminhoAtual != "") {
                        echo "<img class='imagem-atual' src='../" . htmlspecialchars($caminhoAtual, ENT_QUOTES, "UTF-8") . "' alt='Imagem atual do anuncio'>";
                    } else {
                        echo "<div class='detalhes-meta'>Sem imagem</div>";
                    }

                    ?>

                </div>

                <div class="campo">

                    <label for="imagem">Trocar imagem (opcional, JPG, PNG ou WEBP, até 2 MB)</label>

                    <input
                        type="file"
                        name="imagem"
                        id="imagem"
                        accept=".jpg,.jpeg,.png,.webp"
                    >

                </div>

                <button type="submit" class="botao botao-largo">
                    Salvar alterações
                </button>

            </form>

            <div class="acoes">
                <a class="botao botao-contorno botao-pequeno" href="detalhes.php?id=<?php echo (int) $idAnuncio; ?>">
                    Cancelar
                </a>
            </div>

            <?php

            }

            ?>

        </div>

    </main>

    <?php include "../includes/footer.php"; ?>

</body>

</html>

<?php $conexao->close(); ?>
