<?php

session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: ../usuarios/login.php");
    exit;
}

$idLogado = (int) $_SESSION["id_usuario"];

if (!isset($_SESSION["token"])) {
    $_SESSION["token"] = bin2hex(random_bytes(32));
}

include "../conexao.php";
require_once "Anuncio.php";

$anuncio = new Anuncio($conexao);

$idAnuncio = 0;

if (isset($_GET["id"])) {
    $idAnuncio = (int) $_GET["id"];
}

$mensagem = "";
$podeExcluir = false;

$dados = $anuncio->buscarPorId($idAnuncio);

if ($dados == null) {

    http_response_code(404);
    $mensagem = "Este anuncio nao existe ou foi removido.";

} elseif ($dados["id_dono"] != $idLogado) {

    http_response_code(403);
    $mensagem = "Voce nao tem permissao para excluir este anuncio.";

} else {

    $podeExcluir = true;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && $podeExcluir == true) {

    $tokenEnviado = "";

    if (isset($_POST["token"])) {
        $tokenEnviado = $_POST["token"];
    }

    if (hash_equals($_SESSION["token"], $tokenEnviado) == false) {

        $mensagem = "Requisicao invalida. Tente novamente.";

    } else {

        $mensagem = $anuncio->excluir($idAnuncio, $idLogado);

        if ($mensagem == "") {

            $conexao->close();

            header("Location: listar.php?excluido=1");
            exit;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Excluir anuncio - Loja e Amigos</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/anuncios.css">

</head>

<body>

    <?php include "../includes/header.php"; ?>

    <main class="pagina-anuncio">

        <div class="caixa">

            <h1>Excluir anúncio</h1>

            <?php

            if ($mensagem != "") {

                echo "<div class='mensagem'>";
                echo htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8");
                echo "</div>";

            }

            if ($podeExcluir == false) {

                echo "<div class='vazio'>";
                echo "<a class='botao' href='listar.php'>Meus anúncios</a>";
                echo "</div>";

            } else {

            ?>

            <p class="descricao">
                Tem certeza que deseja excluir o anúncio
                <strong><?php echo htmlspecialchars($dados["nome_anuncio"], ENT_QUOTES, "UTF-8"); ?></strong>?
                Esta ação não pode ser desfeita.
            </p>

            <form method="POST" action="">

                <input
                    type="hidden"
                    name="token"
                    value="<?php echo htmlspecialchars($_SESSION["token"], ENT_QUOTES, "UTF-8"); ?>"
                >

                <div class="acoes">

                    <button type="submit" class="botao botao-perigo">
                        Sim, excluir
                    </button>

                    <a class="botao botao-contorno" href="detalhes.php?id=<?php echo (int) $idAnuncio; ?>">
                        Cancelar
                    </a>

                </div>

            </form>

            <?php

            }

            ?>

        </div>

    </main>

    <?php include "../includes/footer.php"; ?>

</body>

</html>

<?php $conexao->close(); ?>
