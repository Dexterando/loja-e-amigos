<?php

session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: ../usuarios/login.php");
    exit;
}

$idLogado = (int) $_SESSION["id_usuario"];

include "../conexao.php";
require_once "Anuncio.php";

$anuncio = new Anuncio($conexao);

$mensagem = "";

if (isset($_GET["excluido"])) {
    $mensagem = "Anuncio excluido com sucesso.";
}

$vendedor = $anuncio->usuarioEhVendedor($idLogado);
$lista = $anuncio->listarDoDono($idLogado);
$total = count($lista);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Meus anuncios - Loja e Amigos</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/pesquisa.css">
    <link rel="stylesheet" href="../assets/css/anuncios.css">

</head>

<body>

    <?php include "../includes/header.php"; ?>

    <main class="pagina-anuncio pagina-larga">

        <?php

        if ($mensagem != "") {

            echo "<div class='mensagem'>";
            echo htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8");
            echo "</div>";

        }

        ?>

        <div class="topo-lista">

            <h1>Meus anúncios (<?php echo $total; ?>)</h1>

            <?php

            if ($vendedor == true) {
                echo "<a class='botao' href='publicar.php'>Publicar anúncio</a>";
            }

            ?>

        </div>

        <?php

        if ($total == 0) {

            echo "<div class='vazio'>";

            if ($vendedor == true) {
                echo "<p>Você ainda não publicou nenhum anúncio.</p>";
                echo "<a class='botao' href='publicar.php'>Publicar anúncio</a>";
            } else {
                echo "<p>Sua conta não está cadastrada como vendedor, por isso não há anúncios publicados.</p>";
            }

            echo "</div>";

        } else {

            echo "<div class='grade'>";

            foreach ($lista as $item) {

                $precoFormatado = number_format($item["preco_centavos"] / 100, 2, ",", ".");
                $dataFormatada = date("d/m/Y", strtotime($item["criado_em"]));

                echo "<div class='item-lista'>";

                echo "<a class='card' href='detalhes.php?id=" . (int) $item["id_anuncio"] . "'>";

                echo "<div class='foto'>";

                if ($item["caminho_imagem"] != "") {
                    echo "<img src='../" . htmlspecialchars($item["caminho_imagem"], ENT_QUOTES, "UTF-8") . "' alt=''>";
                } else {
                    echo "Sem foto";
                }

                echo "</div>";

                echo "<div class='info'>";
                echo "<h3>" . htmlspecialchars($item["nome_anuncio"], ENT_QUOTES, "UTF-8") . "</h3>";
                echo "<p class='preco'>R$ " . $precoFormatado . "</p>";
                echo "<p class='categoria'>" . htmlspecialchars($item["nome_categoria"], ENT_QUOTES, "UTF-8") . "</p>";
                echo "<p class='local'>Publicado em " . $dataFormatada . "</p>";
                echo "</div>";

                echo "</a>";

                echo "<div class='acoes'>";
                echo "<a class='botao botao-contorno botao-pequeno' href='editar.php?id=" . (int) $item["id_anuncio"] . "'>Editar</a>";
                echo "<a class='botao botao-perigo botao-pequeno' href='excluir.php?id=" . (int) $item["id_anuncio"] . "'>Excluir</a>";
                echo "</div>";

                echo "</div>";
            }

            echo "</div>";
        }

        ?>

    </main>

    <?php include "../includes/footer.php"; ?>

</body>

</html>

<?php $conexao->close(); ?>
