<?php
// =====================================================
// anuncios/pesquisar.php
// Página de pesquisa e filtros de anúncios
// A lógica fica na classe Pesquisa (Pesquisa.php);
// aqui a página só usa a classe e mostra o resultado.
// =====================================================

include '../conexao.php';       // cria a variável $conexao (mysqli)
require_once 'Pesquisa.php';    // classe da pesquisa
require_once 'Anuncio.php';     // classe dos anúncios (usada para listar as categorias)

$pesquisa = new Pesquisa($conexao);
$anuncio  = new Anuncio($conexao);

// 1) Ler os filtros da URL
$filtros = $pesquisa->lerFiltros($_GET);

// 2) Fazer a pesquisa
$resultado = $pesquisa->buscar($filtros);

// 3) Listas para os campos de seleção do formulário
$categorias = $anuncio->listarCategorias();
$estados    = $pesquisa->listarEstados();

// Variáveis usadas no HTML abaixo
$busca         = $filtros['busca'];
$categoria     = $filtros['categoria'];
$preco_min     = $filtros['preco_min'];
$preco_max     = $filtros['preco_max'];
$estado        = $filtros['estado'];
$cidade        = $filtros['cidade'];
$ordem         = $filtros['ordem'];

$anuncios      = $resultado['anuncios'];
$total         = $resultado['total'];
$total_paginas = $resultado['total_paginas'];
$pagina        = $resultado['pagina'];

include '../includes/header.php';
?>

<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/pesquisa.css">

<div class="pesquisa">

    <!-- ================= FORMULÁRIO DE FILTROS ================= -->
    <form class="filtros" method="GET" action="pesquisar.php">
        <h2>Filtros</h2>

        <label>O que você procura?</label>
        <input type="text" name="busca" value="<?php echo htmlspecialchars($busca); ?>" placeholder="Ex.: bicicleta">

        <label>Categoria</label>
        <select name="categoria">
            <option value="">Todas</option>
            <?php foreach ($categorias as $cat) { ?>
                <option value="<?php echo $cat['id_categoria']; ?>"
                    <?php if ($categoria == $cat['id_categoria']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($cat['nome_categoria']); ?>
                </option>
            <?php } ?>
        </select>

        <label>Preço mínimo (R$)</label>
        <input type="number" name="preco_min" min="0" step="0.01" value="<?php echo htmlspecialchars($preco_min); ?>">

        <label>Preço máximo (R$)</label>
        <input type="number" name="preco_max" min="0" step="0.01" value="<?php echo htmlspecialchars($preco_max); ?>">

        <label>Estado</label>
        <select name="estado">
            <option value="">Todos</option>
            <?php foreach ($estados as $e) { ?>
                <option value="<?php echo htmlspecialchars($e['estado']); ?>"
                    <?php if ($estado == $e['estado']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($e['estado']); ?>
                </option>
            <?php } ?>
        </select>

        <label>Cidade</label>
        <input type="text" name="cidade" value="<?php echo htmlspecialchars($cidade); ?>" placeholder="Ex.: Campinas">

        <label>Ordenar por</label>
        <select name="ordem">
            <option value="recentes"    <?php if ($ordem == 'recentes')    echo 'selected'; ?>>Mais recentes</option>
            <option value="antigos"     <?php if ($ordem == 'antigos')     echo 'selected'; ?>>Mais antigos</option>
            <option value="menor_preco" <?php if ($ordem == 'menor_preco') echo 'selected'; ?>>Menor preço</option>
            <option value="maior_preco" <?php if ($ordem == 'maior_preco') echo 'selected'; ?>>Maior preço</option>
        </select>

        <button type="submit">Pesquisar</button>
        <a class="limpar" href="pesquisar.php">Limpar filtros</a>
    </form>

    <!-- ================= RESULTADOS ================= -->
    <div class="resultados">

        <p><strong><?php echo $total; ?></strong> anúncio(s) encontrado(s)</p>

        <?php if ($total == 0) { ?>

            <div class="vazio">Nenhum anúncio encontrado. Tente mudar os filtros.</div>

        <?php } else { ?>

            <div class="grade">
                <?php foreach ($anuncios as $anuncio) { ?>
                    <a class="card" href="detalhes.php?id=<?php echo $anuncio['id_anuncio']; ?>">

                        <div class="foto">
                            <?php if ($anuncio['imagem'] != '') { ?>
                                <img src="../<?php echo htmlspecialchars($anuncio['imagem']); ?>">
                            <?php } else { ?>
                                Sem foto
                            <?php } ?>
                        </div>

                        <div class="info">
                            <h3><?php echo htmlspecialchars($anuncio['titulo']); ?></h3>
                            <!-- Descrição em uma linha: mostra por que o anúncio apareceu na busca -->
                            <p class="descricao"><?php echo htmlspecialchars($anuncio['descricao']); ?></p>
                            <p class="preco">R$ <?php echo number_format($anuncio['preco'] / 100, 2, ',', '.'); ?></p>
                            <p class="categoria"><?php echo htmlspecialchars($anuncio['nome_categoria']); ?></p>
                            <p class="local">
                                <?php echo htmlspecialchars(trim(($anuncio['cidade'] ?? '') . (($anuncio['cidade'] ?? '') !== '' && ($anuncio['estado'] ?? '') !== '' ? ' - ' : '') . ($anuncio['estado'] ?? '')) ?: 'Local não informado'); ?>
                                | <?php echo date('d/m/Y', strtotime($anuncio['data_publicacao'])); ?>
                            </p>
                        </div>

                    </a>
                <?php } ?>
            </div>

            <!-- ================= PAGINAÇÃO ================= -->
            <?php if ($total_paginas > 1) { ?>
                <div class="paginacao">
                    <?php
                    for ($p = 1; $p <= $total_paginas; $p++) {
                        // Mantém os filtros e só troca o número da página
                        $parametros = $_GET;
                        $parametros['pagina'] = $p;
                        $link = 'pesquisar.php?' . http_build_query($parametros);

                        if ($p == $pagina) {
                            echo "<span class='atual'>$p</span>";
                        } else {
                            echo "<a href='" . htmlspecialchars($link) . "'>$p</a>";
                        }
                    }
                    ?>
                </div>
            <?php } ?>

        <?php } ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php $conexao->close(); ?>
