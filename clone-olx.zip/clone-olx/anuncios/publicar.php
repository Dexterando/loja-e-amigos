<?php

session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: ../usuarios/login.php");
    exit;
}

$idLogado = (int) $_SESSION["id_usuario"];

if (!isset($_SESSION["token"])) {
    $_SESSION["token"] = bin2hex(random_bytes(32));
}

include "../conexao.php";
require_once "Anuncio.php";

$anuncio = new Anuncio($conexao);
$imagem = new Imagem($conexao);

$mensagem = "";
$titulo = "";
$descricao = "";
$preco = "";
$idCategoria = 0;
$cidade = "";
$estado = "";
$rua = "";
$cep = "";
$numero = "";
$complemento = "";

$vendedor = $anuncio->usuarioEhVendedor($idLogado);
$temLocalizacao = $anuncio->temLocalizacao($idLogado);
$categorias = $anuncio->listarCategorias();

if ($_SERVER["REQUEST_METHOD"] == "POST" && $vendedor == true) {

    $tokenEnviado = "";

    if (isset($_POST["token"])) {
        $tokenEnviado = $_POST["token"];
    }

    $titulo = trim($_POST["titulo"]);
    $descricao = trim($_POST["descricao"]);
    $preco = trim($_POST["preco"]);

    if (isset($_POST["categoria"])) {
        $idCategoria = (int) $_POST["categoria"];
    }

    if ($temLocalizacao == false) {
        $cidade = trim($_POST["cidade"]);
        $estado = strtoupper(trim($_POST["estado"]));
        $rua = trim($_POST["rua"]);
        $cep = trim($_POST["cep"]);
        $numero = trim($_POST["numero"]);
        $complemento = trim($_POST["complemento"]);
    }

    $precoCentavos = 0;

    if (is_numeric($preco)) {
        $precoCentavos = (int) round((float) $preco * 100);
    }

    $arquivo = null;

    if (isset($_FILES["imagem"])) {
        $arquivo = $_FILES["imagem"];
    }

    $mensagemImagem = $imagem->validar($arquivo);

    $localizacaoPreenchida = true;

    if ($temLocalizacao == false) {
        if ($cidade == "" || $estado == "" || $rua == "" || $cep == "" || $numero == "") {
            $localizacaoPreenchida = false;
        }
    }

    if (hash_equals($_SESSION["token"], $tokenEnviado) == false) {

        $mensagem = "Requisicao invalida. Tente novamente.";

    } elseif ($titulo == "" || $descricao == "" || $preco == "") {

        $mensagem = "Preencha todos os campos.";

    } elseif (mb_strlen($titulo, "UTF-8") > 256) {

        $mensagem = "O titulo deve ter no maximo 256 caracteres.";

    } elseif ($precoCentavos <= 0 || $precoCentavos > 999999999) {

        $mensagem = "Digite um preco valido.";

    } elseif ($anuncio->categoriaExiste($idCategoria) == false) {

        $mensagem = "Escolha uma categoria.";

    } elseif ($localizacaoPreenchida == false) {

        $mensagem = "Preencha os dados de localizacao.";

    } elseif ($temLocalizacao == false && strlen($estado) != 2) {

        $mensagem = "Digite a sigla do estado com 2 letras.";

    } elseif ($temLocalizacao == false && preg_match("/^[0-9]{5}-?[0-9]{3}$/", $cep) == 0) {

        $mensagem = "Digite um CEP valido.";

    } elseif ($mensagemImagem != "") {

        $mensagem = $mensagemImagem;

    } else {

        $caminhoBanco = $imagem->salvarArquivo($arquivo);

        if ($caminhoBanco == "") {

            $mensagem = "Erro ao salvar a imagem.";

        } else {

            $local = null;

            if ($temLocalizacao == false) {

                $local = array(
                    "cidade" => $cidade,
                    "estado" => $estado,
                    "rua" => $rua,
                    "cep" => $cep,
                    "numero" => $numero,
                    "complemento" => $complemento
                );
            }

            $idNovo = $anuncio->publicar(
                $idLogado,
                $titulo,
                $descricao,
                $idCategoria,
                $precoCentavos,
                $caminhoBanco,
                $local
            );

            if ($idNovo > 0) {

                $conexao->close();

                header("Location: detalhes.php?id=" . $idNovo . "&publicado=1");
                exit;

            } else {

                $imagem->apagarArquivo($caminhoBanco);

                $mensagem = "Erro ao publicar o anuncio.";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Publicar anuncio - Loja e Amigos</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/anuncios.css">

</head>

<body>

    <?php include "../includes/header.php"; ?>

    <main class="pagina-anuncio">

        <div class="caixa">

            <h1>Publicar anúncio</h1>

            <?php

            if ($mensagem != "") {

                echo "<div class='mensagem'>";
                echo htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8");
                echo "</div>";

            }

            if ($vendedor == false) {

                echo "<div class='vazio'>";
                echo "<p>Sua conta não está cadastrada como vendedor, por isso não é possível publicar anúncios.</p>";
                echo "<a class='botao' href='../usuarios/perfil.php'>Voltar ao perfil</a>";
                echo "</div>";

            } else {

            ?>

            <form method="POST" action="" enctype="multipart/form-data">

                <input
                    type="hidden"
                    name="token"
                    value="<?php echo htmlspecialchars($_SESSION["token"], ENT_QUOTES, "UTF-8"); ?>"
                >

                <div class="campo">

                    <label for="titulo">Título do anúncio</label>

                    <input
                        type="text"
                        name="titulo"
                        id="titulo"
                        maxlength="256"
                        value="<?php echo htmlspecialchars($titulo, ENT_QUOTES, "UTF-8"); ?>"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="categoria">Categoria</label>

                    <select name="categoria" id="categoria" required>

                        <option value="">Selecione</option>

                        <?php

                        foreach ($categorias as $categoriaLista) {

                            $selecionada = "";

                            if ($categoriaLista["id_categoria"] == $idCategoria) {
                                $selecionada = "selected";
                            }

                            echo "<option value='" . (int) $categoriaLista["id_categoria"] . "' " . $selecionada . ">";
                            echo htmlspecialchars($categoriaLista["nome_categoria"], ENT_QUOTES, "UTF-8");
                            echo "</option>";
                        }

                        ?>

                    </select>

                </div>

                <div class="campo">

                    <label for="preco">Preço (R$)</label>

                    <input
                        type="number"
                        name="preco"
                        id="preco"
                        min="0.01"
                        step="0.01"
                        value="<?php echo htmlspecialchars($preco, ENT_QUOTES, "UTF-8"); ?>"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="descricao">Descrição</label>

                    <textarea
                        name="descricao"
                        id="descricao"
                        rows="6"
                        required
                    ><?php echo htmlspecialchars($descricao, ENT_QUOTES, "UTF-8"); ?></textarea>

                </div>

                <div class="campo">

                    <label for="imagem">Imagem (JPG, PNG ou WEBP, até 2 MB)</label>

                    <input
                        type="file"
                        name="imagem"
                        id="imagem"
                        accept=".jpg,.jpeg,.png,.webp"
                        required
                    >

                </div>

                <?php

                if ($temLocalizacao == false) {

                ?>

                <h2>Localização do anúncio</h2>

                <div class="linha-campos">

                    <div class="campo">

                        <label for="cidade">Cidade</label>

                        <input
                            type="text"
                            name="cidade"
                            id="cidade"
                            maxlength="150"
                            value="<?php echo htmlspecialchars($cidade, ENT_QUOTES, "UTF-8"); ?>"
                            required
                        >

                    </div>

                    <div class="campo campo-pequeno">

                        <label for="estado">Estado (UF)</label>

                        <input
                            type="text"
                            name="estado"
                            id="estado"
                            maxlength="2"
                            value="<?php echo htmlspecialchars($estado, ENT_QUOTES, "UTF-8"); ?>"
                            required
                        >

                    </div>

                </div>

                <div class="campo">

                    <label for="rua">Rua</label>

                    <input
                        type="text"
                        name="rua"
                        id="rua"
                        maxlength="150"
                        value="<?php echo htmlspecialchars($rua, ENT_QUOTES, "UTF-8"); ?>"
                        required
                    >

                </div>

                <div class="linha-campos">

                    <div class="campo">

                        <label for="cep">CEP</label>

                        <input
                            type="text"
                            name="cep"
                            id="cep"
                            maxlength="9"
                            placeholder="00000-000"
                            value="<?php echo htmlspecialchars($cep, ENT_QUOTES, "UTF-8"); ?>"
                            required
                        >

                    </div>

                    <div class="campo campo-pequeno">

                        <label for="numero">Número</label>

                        <input
                            type="text"
                            name="numero"
                            id="numero"
                            maxlength="10"
                            value="<?php echo htmlspecialchars($numero, ENT_QUOTES, "UTF-8"); ?>"
                            required
                        >

                    </div>

                </div>

                <div class="campo">

                    <label for="complemento">Complemento (opcional)</label>

                    <input
                        type="text"
                        name="complemento"
                        id="complemento"
                        maxlength="256"
                        value="<?php echo htmlspecialchars($complemento, ENT_QUOTES, "UTF-8"); ?>"
                    >

                </div>

                <?php

                }

                ?>

                <button type="submit" class="botao botao-largo">
                    Publicar anúncio
                </button>

            </form>

            <?php

            }

            ?>

        </div>

    </main>

    <?php include "../includes/footer.php"; ?>

</body>

</html>

<?php $conexao->close(); ?>
