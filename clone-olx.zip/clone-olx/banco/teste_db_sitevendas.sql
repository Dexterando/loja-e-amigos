-- =====================================================
-- teste_db_sitevendas_mesclado.sql
-- Estrutura oficial de banco.sql + dados originais de teste_db_sitevendas.sql
-- ATENCAO: apaga e recria as tabelas do db_sitevendas. Use apenas em ambiente de teste.
-- Senha dos usuarios de teste: 123456
-- =====================================================

SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS db_sitevendas;
USE db_sitevendas;

-- Limpeza na ordem das dependencias (tabelas filhas antes das pais)
DROP TABLE IF EXISTS pedido;
DROP TABLE IF EXISTS favoritos;
DROP TABLE IF EXISTS historico;
DROP TABLE IF EXISTS anuncios;
DROP TABLE IF EXISTS localizacao_cliente;
DROP TABLE IF EXISTS imagens;
DROP TABLE IF EXISTS categoria;
DROP TABLE IF EXISTS usuario;

-- ===== ESTRUTURA ORIGINAL DE banco.sql =====
CREATE TABLE IF NOT EXISTS categoria (
    id_categoria INT AUTO_INCREMENT NOT NULL,
    nome_categoria VARCHAR(256) NOT NULL,
    PRIMARY KEY (id_categoria)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS imagens (
    id_imagem INT AUTO_INCREMENT NOT NULL,
    caminho_imagem VARCHAR(256) NOT NULL,
    PRIMARY KEY (id_imagem)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS usuario (
    id_usuario INT AUTO_INCREMENT NOT NULL,
    nome_user VARCHAR(256) NOT NULL,
    senha_hash VARCHAR(256) NOT NULL,
    email_user VARCHAR(256) NOT NULL UNIQUE,
    data_nascimento DATE NOT NULL,
    vendedor BOOLEAN DEFAULT 0,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS localizacao_cliente (
    id_localizacao INT AUTO_INCREMENT NOT NULL,
    id_dono INT NOT NULL,
    cidade VARCHAR(150) NOT NULL,
    estado VARCHAR(2) NOT NULL,
    rua VARCHAR(150) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    numero VARCHAR(10) NOT NULL,
    complemento VARCHAR(256) NOT NULL,
    PRIMARY KEY (id_localizacao),
    FOREIGN KEY (id_dono) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS anuncios (
    id_anuncio INT AUTO_INCREMENT NOT NULL,
    id_dono INT NOT NULL,
    nome_anuncio VARCHAR(256) NOT NULL,
    descricao_anuncio TEXT NOT NULL,
    id_imagem INT NOT NULL,
    id_categoria INT NOT NULL,
    preco_centavos INT NOT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_anuncio),
    FOREIGN KEY (id_dono) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_imagem) REFERENCES imagens(id_imagem),
    FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pedido (
    id_pedido INT AUTO_INCREMENT NOT NULL,
    id_vendedor INT NOT NULL,
    id_comprador INT NOT NULL,
    id_anuncio INT NOT NULL,
    id_localizacao INT NOT NULL,
    preco_centavos INT NOT NULL,
    status_pedido BOOLEAN,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_pedido),
    FOREIGN KEY (id_vendedor) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_comprador) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_anuncio) REFERENCES anuncios(id_anuncio),
    FOREIGN KEY (id_localizacao) REFERENCES localizacao_cliente(id_localizacao)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS favoritos (
    id_favorito INT AUTO_INCREMENT NOT NULL,
    id_dono INT NOT NULL,
    id_anuncio INT NOT NULL,
    PRIMARY KEY (id_favorito),
    FOREIGN KEY (id_dono) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_anuncio) REFERENCES anuncios(id_anuncio)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS historico (
    id_historico INT AUTO_INCREMENT NOT NULL,
    id_dono INT NOT NULL,
    descricao_historico TEXT NOT NULL,
    ocorrido_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_historico),
    FOREIGN KEY (id_dono) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;


-- ===== DADOS ORIGINAIS DE TESTE, AJUSTADOS PARA O SCHEMA OFICIAL =====
INSERT INTO usuario (id_usuario, nome_user, senha_hash, email_user, data_nascimento, vendedor) VALUES
(1, 'Ana Souza', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'ana@email.com', '2000-05-10', 1),
(2, 'Bruno Lima', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'bruno@email.com', '1994-02-21', 1),
(3, 'Carla Mendes', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'carla@email.com', '2003-09-03', 1),
(4, 'Diego Rocha', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'diego@email.com', '1985-12-30', 1),
(5, 'Elisa Martins', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'elisa@email.com', '1997-07-15', 0);

INSERT INTO categoria (id_categoria, nome_categoria) VALUES
(1, 'Celulares'), (2, 'Eletrônicos'), (3, 'Móveis'), (4, 'Roupas'), (5, 'Veículos'), (6, 'Esportes');

-- O teste original não fornecia imagens. São usados caminhos fictícios de placeholder
-- (um registro por anúncio para cumprir a FK NOT NULL; troque pelos arquivos reais).
INSERT INTO imagens (id_imagem, caminho_imagem) VALUES
(1, 'assets/imagens/teste/anuncio_01.jpg'), (2, 'assets/imagens/teste/anuncio_02.jpg'),
(3, 'assets/imagens/teste/anuncio_03.jpg'), (4, 'assets/imagens/teste/anuncio_04.jpg'),
(5, 'assets/imagens/teste/anuncio_05.jpg'), (6, 'assets/imagens/teste/anuncio_06.jpg'),
(7, 'assets/imagens/teste/anuncio_07.jpg'), (8, 'assets/imagens/teste/anuncio_08.jpg'),
(9, 'assets/imagens/teste/anuncio_09.jpg'), (10, 'assets/imagens/teste/anuncio_10.jpg'),
(11, 'assets/imagens/teste/anuncio_11.jpg'), (12, 'assets/imagens/teste/anuncio_12.jpg'),
(13, 'assets/imagens/teste/anuncio_13.jpg'), (14, 'assets/imagens/teste/anuncio_14.jpg'),
(15, 'assets/imagens/teste/anuncio_15.jpg'), (16, 'assets/imagens/teste/anuncio_16.jpg'),
(17, 'assets/imagens/teste/anuncio_17.jpg'), (18, 'assets/imagens/teste/anuncio_18.jpg'),
(19, 'assets/imagens/teste/anuncio_19.jpg'), (20, 'assets/imagens/teste/anuncio_20.jpg'),
(21, 'assets/imagens/teste/anuncio_21.jpg');

-- preco original (reais) convertido para centavos. cidade/estado/status/data_publicacao
-- não existem no schema oficial e, por isso, não são gravados como colunas.
INSERT INTO anuncios (id_anuncio, id_dono, nome_anuncio, descricao_anuncio, id_imagem, id_categoria, preco_centavos) VALUES
(1, 1, 'iPhone 13 128GB Azul', 'Bateria 89%, com caixa e carregador.', 1, 1, 280000),
(2, 3, 'Samsung Galaxy S23', 'Novo, lacrado, com nota fiscal.', 2, 1, 350000),
(3, 4, 'Xiaomi Redmi Note 12', 'Pouco uso, sem arranhões.', 3, 1, 90000),
(4, 2, 'iPhone 11 64GB Preto', 'Tela trocada, funcionando tudo.', 4, 1, 150000),
(5, 4, 'Notebook Dell Inspiron i5', '8GB RAM, SSD 256GB.', 5, 2, 220000),
(6, 1, 'Smart TV LG 50 polegadas', '4K, Wi-Fi, controle original.', 6, 2, 190000),
(7, 3, 'Fone Bluetooth JBL', 'Cancelamento de ruído, azul.', 7, 2, 35000),
(8, 2, 'Sofá 3 lugares cinza', 'Tecido suede, ótimo estado.', 8, 3, 75000),
(9, 4, 'Mesa de jantar 6 cadeiras', 'Madeira maciça.', 9, 3, 120000),
(10, 3, 'Guarda-roupa casal branco', '6 portas.', 10, 3, 98000),
(11, 1, 'Jaqueta de couro preta', 'Tamanho M, pouco usada.', 11, 4, 28000),
(12, 1, 'Tênis Nike Air Max 42', 'Original, na caixa.', 12, 4, 45000),
(13, 4, 'Honda CG 160 2020', '25 mil km, documentação ok.', 13, 5, 1350000),
(14, 2, 'Fiat Uno 2012', 'Completo, revisado.', 14, 5, 2200000),
(15, 3, 'Bicicleta aro 29', '21 marchas, freio a disco.', 15, 6, 110000),
(16, 3, 'Bola de futebol Adidas', 'Oficial, nova.', 16, 6, 15000),
(17, 1, 'Esteira elétrica', 'Dobrável, 12 km/h.', 17, 6, 160000),
(18, 2, 'Videogame PlayStation 5', 'Com 2 controles e 3 jogos.', 18, 2, 380000),
(19, 3, 'Cadeira gamer roxa', 'Reclinável, apoio de braço.', 19, 3, 65000),
(20, 4, 'Capinha iPhone 13', 'Silicone, várias cores.', 20, 1, 3000),
(21, 1, 'Câmera Canon T6', 'Com lente 18-55mm e bolsa.', 21, 2, 170000);

-- Favoritos originais da Elisa, IDs dos anúncios mantidos.
INSERT INTO favoritos (id_dono, id_anuncio) VALUES
(5, 1), (5, 8), (5, 15);

-- Datas diferentes para testar a ordenação "Mais recentes" / "Mais antigos".
UPDATE anuncios SET criado_em = CASE id_anuncio
    WHEN 1 THEN '2026-11-01 10:00:00'  WHEN 2 THEN '2026-11-10 14:30:00'  WHEN 3 THEN '2026-10-20 09:15:00'
    WHEN 4 THEN '2026-11-18 16:00:00'  WHEN 5 THEN '2026-11-05 16:00:00'  WHEN 6 THEN '2026-11-15 11:20:00'
    WHEN 7 THEN '2026-11-19 08:45:00'  WHEN 8 THEN '2026-10-28 13:00:00'  WHEN 9 THEN '2026-11-02 17:40:00'
    WHEN 10 THEN '2026-11-12 10:10:00' WHEN 11 THEN '2026-11-08 15:25:00' WHEN 12 THEN '2026-11-20 12:00:00'
    WHEN 13 THEN '2026-10-15 09:00:00' WHEN 14 THEN '2026-11-09 10:30:00' WHEN 15 THEN '2026-11-11 18:00:00'
    WHEN 16 THEN '2026-11-21 07:30:00' WHEN 17 THEN '2026-11-14 19:00:00' WHEN 18 THEN '2026-11-22 09:00:00'
    WHEN 19 THEN '2026-11-16 20:00:00' WHEN 20 THEN '2026-11-23 08:00:00' WHEN 21 THEN '2026-10-10 10:00:00'
END;

-- Localização de cada usuário (a cidade/estado do anúncio vem daqui, pelo id_dono).
INSERT INTO localizacao_cliente (id_dono, cidade, estado, rua, cep, numero, complemento) VALUES
(1, 'São Paulo',      'SP', 'Av. Paulista',   '01310-100', '1000', 'Apto 12'),
(2, 'Campinas',       'SP', 'Rua Barão',      '13010-000', '50',   ''),
(3, 'Rio de Janeiro', 'RJ', 'Rua Primeiro',   '20040-000', '12',   'Casa'),
(4, 'Belo Horizonte', 'MG', 'Rua Pernambuco', '30110-000', '300',  ''),
(5, 'Curitiba',       'PR', 'Rua XV',         '80010-000', '88',   'Bloco B');

-- =====================================================
-- DADOS ADICIONAIS: 10 NOVOS USUÁRIOS (IDs 6 a 15)
-- =====================================================
INSERT INTO usuario (id_usuario, nome_user, senha_hash, email_user, data_nascimento, vendedor) VALUES
(6, 'Felipe Castro', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'felipe@email.com', '1992-03-14', 1),
(7, 'Mariana Dias', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'mariana@email.com', '1998-11-20', 1),
(8, 'Lucas Ribeiro', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'lucas@email.com', '2001-06-05', 0),
(9, 'Beatriz Souza', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'beatriz@email.com', '1995-01-18', 1),
(10, 'Gabriel Nunes', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'gabriel@email.com', '1989-08-22', 0),
(11, 'Juliana Alves', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'juliana@email.com', '2002-04-12', 1),
(12, 'Rafael Martins', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'rafael@email.com', '1990-10-30', 0),
(13, 'Camila Fernandes', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'camila@email.com', '1996-12-05', 1),
(14, 'Thiago Santos', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'thiago@email.com', '1993-07-25', 1),
(15, 'Larissa Moreira', '$2y$10$kj1FEA0c5N79juLRbLiN.O4V6WoX74s6NosZH/qFiF.lLrcQIhq8C', 'larissa@email.com', '2000-09-15', 0);

-- =====================================================
-- DADOS ADICIONAIS: 5 NOVAS CATEGORIAS (IDs 7 a 11)
-- =====================================================
INSERT INTO categoria (id_categoria, nome_categoria) VALUES
(7, 'Livros'), 
(8, 'Beleza'), 
(9, 'Brinquedos'), 
(10, 'Ferramentas'), 
(11, 'Imóveis');

-- =====================================================
-- DADOS ADICIONAIS: 20 NOVAS IMAGENS (IDs 22 a 41)
-- =====================================================
INSERT INTO imagens (id_imagem, caminho_imagem) VALUES
(22, 'assets/imagens/teste/anuncio_22.jpg'), (23, 'assets/imagens/teste/anuncio_23.jpg'),
(24, 'assets/imagens/teste/anuncio_24.jpg'), (25, 'assets/imagens/teste/anuncio_25.jpg'),
(26, 'assets/imagens/teste/anuncio_26.jpg'), (27, 'assets/imagens/teste/anuncio_27.jpg'),
(28, 'assets/imagens/teste/anuncio_28.jpg'), (29, 'assets/imagens/teste/anuncio_29.jpg'),
(30, 'assets/imagens/teste/anuncio_30.jpg'), (31, 'assets/imagens/teste/anuncio_31.jpg'),
(32, 'assets/imagens/teste/anuncio_32.jpg'), (33, 'assets/imagens/teste/anuncio_33.jpg'),
(34, 'assets/imagens/teste/anuncio_34.jpg'), (35, 'assets/imagens/teste/anuncio_35.jpg'),
(36, 'assets/imagens/teste/anuncio_36.jpg'), (37, 'assets/imagens/teste/anuncio_37.jpg'),
(38, 'assets/imagens/teste/anuncio_38.jpg'), (39, 'assets/imagens/teste/anuncio_39.jpg'),
(40, 'assets/imagens/teste/anuncio_40.jpg'), (41, 'assets/imagens/teste/anuncio_41.jpg');

-- =====================================================
-- DADOS ADICIONAIS: 20 NOVOS ANÚNCIOS (IDs 22 a 41)
-- =====================================================
INSERT INTO anuncios (id_anuncio, id_dono, nome_anuncio, descricao_anuncio, id_imagem, id_categoria, preco_centavos) VALUES
(22, 6, 'Livro - O Senhor dos Anéis', 'Edição única, capa dura.', 22, 7, 8500),
(23, 7, 'Perfume Masculino 100ml', 'Fragrância amadeirada, original.', 23, 8, 14000),
(24, 9, 'Kit Lego Star Wars', 'Completo com manual e caixa.', 24, 9, 32000),
(25, 11, 'Furadeira Parafusadeira Bosch', 'Bateria 18V bivolt.', 25, 10, 45000),
(26, 13, 'Apartamento na Praia', 'Aluguel de temporada, 2 quartos.', 26, 11, 250000),
(27, 6, 'Box Harry Potter Completo', '7 livros em ótimo estado.', 27, 7, 12000),
(28, 7, 'Kit Maquiagem Profissional', 'Paleta de sombras e pincéis.', 28, 8, 9500),
(29, 9, 'Boneca Reborn Realista', 'Com acessórios e certidão.', 29, 9, 28000),
(30, 11, 'Jogo de Chaves de Fenda e Allen', '10 peças em aço cromo.', 30, 10, 6000),
(31, 13, 'Kit Skincare Completo', 'Produtos importados.', 31, 8, 18000),
(32, 6, 'Livro - Clean Code', 'Português, impecável.', 32, 7, 7000),
(33, 7, 'Carrinho de Controle Remoto', 'Escala 1:10, bateria recarregável.', 33, 9, 21000),
(34, 9, 'Kit de Ferramentas Manuais', 'Com maleta plástica.', 34, 10, 15000),
(35, 11, 'Casa em Condomínio Fechado', 'Venda, 3 dormitórios.', 35, 11, 85000000),
(36, 13, 'Secador de Cabelo Profissional', '2200W, íons negativos.', 36, 8, 22000),
(37, 6, 'Tabuleiro de Xadrez em Madeira', 'Peças entalhadas à mão.', 37, 9, 13000),
(38, 7, 'Livro - Sapiens: Uma Breve História', 'Capa comum.', 38, 7, 5000),
(39, 9, 'Serra Circular de Bancada', '1500W, mesa inclinável.', 39, 10, 78000),
(40, 11, 'Skate Profissional Maple', 'Rolamentos ABEC-9.', 40, 9, 19000),
(41, 13, 'Chapinha Alisadora Titanium', 'Temperatura até 230°C.', 41, 8, 16000);

-- =====================================================
-- ATUALIZAÇÃO DE DATAS PARA OS NOVOS ANÚNCIOS
-- =====================================================
UPDATE anuncios SET criado_em = CASE id_anuncio
    WHEN 22 THEN '2026-11-23 10:00:00' WHEN 23 THEN '2026-11-23 11:00:00' WHEN 24 THEN '2026-11-23 12:00:00'
    WHEN 25 THEN '2026-11-23 13:00:00' WHEN 26 THEN '2026-11-23 14:00:00' WHEN 27 THEN '2026-11-23 15:00:00'
    WHEN 28 THEN '2026-11-23 16:00:00' WHEN 29 THEN '2026-11-23 17:00:00' WHEN 30 THEN '2026-11-23 18:00:00'
    WHEN 31 THEN '2026-11-24 08:00:00' WHEN 32 THEN '2026-11-24 09:00:00' WHEN 33 THEN '2026-11-24 10:00:00'
    WHEN 34 THEN '2026-11-24 11:00:00' WHEN 35 THEN '2026-11-24 12:00:00' WHEN 36 THEN '2026-11-24 13:00:00'
    WHEN 37 THEN '2026-11-24 14:00:00' WHEN 38 THEN '2026-11-24 15:00:00' WHEN 39 THEN '2026-11-24 16:00:00'
    WHEN 40 THEN '2026-11-24 17:00:00' WHEN 41 THEN '2026-11-24 18:00:00'
END WHERE id_anuncio BETWEEN 22 AND 41;

-- =====================================================
-- LOCALIZAÇÃO PARA OS 10 NOVOS USUÁRIOS (IDs 6 a 15)
-- =====================================================
INSERT INTO localizacao_cliente (id_dono, cidade, estado, rua, cep, numero, complemento) VALUES
(6, 'Porto Alegre',   'RS', 'Av. Borges de Medeiros', '90020-024', '400',  'Sala 501'),
(7, 'Florianópolis',  'SC', 'Rua das Flores',         '88010-010', '120',  ''),
(8, 'Salvador',       'BA', 'Av. Sete de Setembro',   '40060-001', '1500', 'Apto 302'),
(9, 'Recife',         'PE', 'Boa Viagem',             '51020-010', '330',  ''),
(10, 'Fortaleza',     'CE', 'Av. Beira Mar',          '60165-121', '800',  'Cobertura'),
(11, 'Curitiba',      'PR', 'Rua 24 Horas',           '80420-010', '55',   ''),
(12, 'Brasília',      'DF', 'Esplanada dos Ministérios','70050-000', '1',    'Bloco A'),
(13, 'Goiânia',       'GO', 'Av. Goiás',              '74010-010', '900',  ''),
(14, 'Manaus',        'AM', 'Av. Eduardo Ribeiro',    '69010-001', '200',  ''),
(15, 'Vitória',       'ES', 'Rua do Centenário',      '29010-010', '77',   '');

-- Pedidos e histórico ficam criados e vazios.
