<!-- Barra de pesquisa: inclua este arquivo no header.php ou no index.php -->
<form class="barra-pesquisa" method="GET" action="/clone-olx/anuncios/pesquisar.php">
    <input type="text" name="busca" placeholder="Buscar celulares, móveis, carros...">
    <button type="submit">Buscar</button>
</form>
