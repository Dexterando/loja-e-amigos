<?php
require_once __DIR__ . '/sessao.php';
// Descobre a URL da raiz do projeto a partir da página acessada.
// Funciona na página inicial e também em páginas dentro de /anuncios ou /usuarios.
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
if (preg_match('~/(anuncios|usuarios)$~', $scriptDir)) {
    $scriptDir = dirname($scriptDir);
}
$baseUrl = ($scriptDir === '/' || $scriptDir === '.') ? '' : rtrim($scriptDir, '/');

// Busca as categorias no banco. O require_once também funciona nas páginas
// que já carregaram conexao.php anteriormente.
$categoriasHeader = [];
require_once __DIR__ . '/../conexao.php';

if (isset($conexao) && $conexao instanceof mysqli) {
    try {
        $resultadoCategoriasHeader = $conexao->query(
            "SELECT id_categoria, nome_categoria FROM categoria ORDER BY nome_categoria ASC"
        );
        if ($resultadoCategoriasHeader) {
            $categoriasHeader = $resultadoCategoriasHeader->fetch_all(MYSQLI_ASSOC);
            $resultadoCategoriasHeader->free();
        }
    } catch (mysqli_sql_exception $erro) {
        $categoriasHeader = [];
    }
}
?>

<header class="site-header">

    <div class="header-container">

        <!-- LOGO -->
        <a href="<?= htmlspecialchars($baseUrl . '/index.php', ENT_QUOTES, 'UTF-8') ?>" class="logo">
            <img src="<?= htmlspecialchars($baseUrl . '/assets/imagens/logo.jpg', ENT_QUOTES, 'UTF-8') ?>"
                 alt="Loja e Amigos">
        </a>

        <!-- LOCALIZAÇÃO -->
        <div class="location-box">
            <span class="location-icon">⌖</span>

            <div>
                <small>Você está em</small>
                <strong>Escolher localização</strong>
            </div>
        </div>

        <!-- PESQUISA -->
        <form action="<?= htmlspecialchars($baseUrl . '/anuncios/pesquisar.php', ENT_QUOTES, 'UTF-8') ?>" method="GET" class="search-box">

            <input
                type="search"
                name="busca"
                placeholder="O que você está procurando?"
            >

            <button type="submit">Pesquisar</button>

        </form>

        <!-- AÇÕES -->
        <nav class="header-actions">

            <?php if (!empty($_SESSION['id_usuario'])): ?>
                <a href="<?= htmlspecialchars($baseUrl . '/usuarios/perfil.php', ENT_QUOTES, 'UTF-8') ?>"
                   class="header-profile">
                    Meu perfil
                </a>
            <?php else: ?>
                <a href="<?= htmlspecialchars($baseUrl . '/usuarios/login.php', ENT_QUOTES, 'UTF-8') ?>">
                    Entrar
                </a>

                <a href="<?= htmlspecialchars($baseUrl . '/usuarios/cadastro.php', ENT_QUOTES, 'UTF-8') ?>">
                    Cadastrar
                </a>
            <?php endif; ?>

            <a href="<?= htmlspecialchars($baseUrl . '/anuncios/publicar.php', ENT_QUOTES, 'UTF-8') ?>"
               class="btn-anunciar">
                Anunciar grátis
            </a>

        </nav>

    </div>

    <!-- CATEGORIAS -->
    <div class="header-categories">

        <nav class="categories-nav">
            <a class="category-option" href="<?= htmlspecialchars($baseUrl . '/anuncios/pesquisar.php', ENT_QUOTES, 'UTF-8') ?>">Todas</a>
            <?php foreach ($categoriasHeader as $categoriaHeader): ?>
                <a class="category-option"
                   href="<?= htmlspecialchars($baseUrl . '/anuncios/pesquisar.php?categoria=' . (int) $categoriaHeader['id_categoria'], ENT_QUOTES, 'UTF-8') ?>">
                    <?= htmlspecialchars($categoriaHeader['nome_categoria'], ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php endforeach; ?>
        </nav>

    </div>

</header>
