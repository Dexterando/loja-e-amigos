<?php
// Inicializa a mesma sessao em todas as paginas do projeto.
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
