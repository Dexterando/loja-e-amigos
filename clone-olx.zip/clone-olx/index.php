<?php
require_once __DIR__ . '/conexao.php';

function buscarAnunciosHome(mysqli $conexao, string $condicao, string $ordem, int $limite = 12): array
{
    $sql = "SELECT a.id_anuncio, a.nome_anuncio, a.preco_centavos, a.criado_em,
                   i.caminho_imagem,
                   lc.cidade, lc.estado
            FROM anuncios a
            LEFT JOIN imagens i ON i.id_imagem = a.id_imagem
            LEFT JOIN localizacao_cliente lc ON lc.id_localizacao = (
                SELECT MAX(l2.id_localizacao)
                FROM localizacao_cliente l2
                WHERE l2.id_dono = a.id_dono
            )
            WHERE {$condicao}
            ORDER BY {$ordem}
            LIMIT {$limite}";
    $resultado = $conexao->query($sql);
    return $resultado ? $resultado->fetch_all(MYSQLI_ASSOC) : [];
}

$secoesHome = [
    [
        'titulo' => 'Preços mais baixos (até R$ 200)',
        'condicao' => 'a.preco_centavos < 20000',
        'ordem' => 'a.preco_centavos ASC, a.criado_em DESC'
    ],
    [
        'titulo' => 'Mais recentes',
        'condicao' => '1=1',
        'ordem' => 'a.criado_em DESC'
    ],
    [
        'titulo' => 'Tecnologia',
        'condicao' => "EXISTS (SELECT 1 FROM categoria c WHERE c.id_categoria = a.id_categoria AND (c.nome_categoria LIKE '%Celular%' OR c.nome_categoria LIKE '%Eletr%'))",
        'ordem' => 'a.criado_em DESC'
    ],
    [
        'titulo' => 'Moda e beleza',
        'condicao' => "EXISTS (SELECT 1 FROM categoria c WHERE c.id_categoria = a.id_categoria AND (c.nome_categoria LIKE '%Roupa%' OR c.nome_categoria LIKE '%Beleza%'))",
        'ordem' => 'a.criado_em DESC'
    ],
    [
        'titulo' => 'Mais perto de você — São Paulo',
        'condicao' => "EXISTS (SELECT 1 FROM localizacao_cliente lf WHERE lf.id_dono = a.id_dono AND lf.estado = 'SP')",
        'ordem' => 'a.criado_em DESC'
    ],
    [
        'titulo' => 'Automóveis',
        'condicao' => "EXISTS (SELECT 1 FROM categoria c WHERE c.id_categoria = a.id_categoria AND (c.nome_categoria LIKE '%Veículo%' OR c.nome_categoria LIKE '%Automóv%'))",
        'ordem' => 'a.criado_em DESC'
    ]
];

foreach ($secoesHome as &$secaoHome) {
    $secaoHome['anuncios'] = buscarAnunciosHome($conexao, $secaoHome['condicao'], $secaoHome['ordem']);
}
unset($secaoHome);

$baseUrlHome = '';
$scriptDirHome = str_replace('\\\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
if ($scriptDirHome !== '/' && $scriptDirHome !== '.') {
    $baseUrlHome = rtrim($scriptDirHome, '/');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loja e Amigos | Classificados</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="home-main">
        <?php foreach ($secoesHome as $indiceSecao => $secaoHome): ?>
            <section class="home-section">
                <div class="home-section-heading">
                    <h2><?= htmlspecialchars($secaoHome['titulo'], ENT_QUOTES, 'UTF-8') ?></h2>
                    <a href="anuncios/pesquisar.php">Ver todos</a>
                </div>

                <?php if (!empty($secaoHome['anuncios'])): ?>
                    <div class="home-products-row">
                        <?php foreach ($secaoHome['anuncios'] as $anuncioHome): ?>
                            <?php
                                $caminhoImagem = trim((string) ($anuncioHome['caminho_imagem'] ?? ''));
                                $srcImagem = $caminhoImagem !== ''
                                    ? $baseUrlHome . '/' . ltrim($caminhoImagem, '/')
                                    : '';
                                $precoFormatado = number_format(((int) $anuncioHome['preco_centavos']) / 100, 2, ',', '.');
                                $localAnuncio = trim(($anuncioHome['cidade'] ?? '') . ' - ' . ($anuncioHome['estado'] ?? ''), ' -');
                            ?>
                            <a class="home-product-card"
                               href="anuncios/detalhes.php?id=<?= (int) $anuncioHome['id_anuncio'] ?>">
                                <div class="home-product-image">
                                    <?php if ($srcImagem !== ''): ?>
                                        <img src="<?= htmlspecialchars($srcImagem, ENT_QUOTES, 'UTF-8') ?>"
                                             alt="<?= htmlspecialchars($anuncioHome['nome_anuncio'], ENT_QUOTES, 'UTF-8') ?>"
                                             loading="lazy">
                                    <?php else: ?>
                                        <span>Sem imagem</span>
                                    <?php endif; ?>
                                </div>
                                <h3><?= htmlspecialchars($anuncioHome['nome_anuncio'], ENT_QUOTES, 'UTF-8') ?></h3>
                                <strong class="home-product-price">R$ <?= $precoFormatado ?></strong>
                                <div class="home-product-meta">
                                    <span><?= date('d/m/Y', strtotime($anuncioHome['criado_em'])) ?></span>
                                    <?php if ($localAnuncio !== ''): ?>
                                        <span><?= htmlspecialchars($localAnuncio, ENT_QUOTES, 'UTF-8') ?></span>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="home-empty">Ainda não há anúncios nesta seleção.</p>
                <?php endif; ?>
            </section>
        <?php endforeach; ?>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
