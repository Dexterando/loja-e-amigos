
<?php
require_once __DIR__ . '/../includes/sessao.php';

// CONEXAO COM O BANCO (dados da conexao ficam no conexao.php)

include "../conexao.php";


// VARIAVEIS

$mensagem = "";
$nome = "";
$email = "";
$dataNascimento = "";
$vendedor = 0;


// VERIFICAR ENVIO DO FORMULARIO

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = trim($_POST["nome"]);
    $email = trim($_POST["email"]);
    $dataNascimento = $_POST["dataNascimento"];
    $senhaUsuario = $_POST["senha"];
    $confirmarSenha = $_POST["confirmarSenha"];

    if (isset($_POST["vendedor"])) {
        $vendedor = 1;
    }


    // VALIDAR OS DADOS

    $dataValida = false;

    if (preg_match("/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/", $dataNascimento) == 1) {

        $partesData = explode("-", $dataNascimento);

        $dataValida = checkdate(
            (int) $partesData[1],
            (int) $partesData[2],
            (int) $partesData[0]
        );
    }

    if ($nome == "" || $email == "" || $senhaUsuario == "" || $confirmarSenha == "" || $dataNascimento == "") {

        $mensagem = "Preencha todos os campos.";

    } elseif (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {

        $mensagem = "Digite um e-mail valido.";

    } elseif ($dataValida == false) {

        $mensagem = "Digite uma data valida.";

    } elseif (strlen($senhaUsuario) < 8) {

        $mensagem = "A senha deve ter pelo menos 8 caracteres.";

    } elseif ($senhaUsuario != $confirmarSenha) {

        $mensagem = "As senhas nao correspondem.";

    } else {

        // VERIFICAR SE O EMAIL JA EXISTE

        $consulta = $conexao->prepare(
            "SELECT id_usuario FROM usuario WHERE email_user = ?"
        );

        $consulta->bind_param("s", $email);
        $consulta->execute();
        $consulta->store_result();

        if ($consulta->num_rows > 0) {

            $mensagem = "Este e-mail ja esta cadastrado.";

        } else {

            // PROTEGER A SENHA

            $senhaHash = password_hash(
                $senhaUsuario,
                PASSWORD_DEFAULT
            );


            // CADASTRAR USUARIO

            $insercao = $conexao->prepare(
                "INSERT INTO usuario
                (nome_user, senha_hash, email_user, data_nascimento, vendedor)
                VALUES (?, ?, ?, ?, ?)"
            );

            $insercao->bind_param(
                "ssssi",
                $nome,
                $senhaHash,
                $email,
                $dataNascimento,
                $vendedor
            );

            if ($insercao->execute()) {

                // Autentica automaticamente a conta recem-criada.
                session_regenerate_id(true);
                $_SESSION["id_usuario"] = (int) $conexao->insert_id;
                $_SESSION["nome_usuario"] = $nome;
                $_SESSION["email_usuario"] = $email;

                $insercao->close();
                $consulta->close();
                $conexao->close();

                header("Location: perfil.php");
                exit;

            } else {

                $mensagem = "Erro ao realizar cadastro.";

            }

            $insercao->close();
        }

        $consulta->close();
    }
}

$conexao->close();

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cadastro - Loja e Amigos</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f2fa;
            color: #302442;
        }

        header {
            background-color: white;
            padding: 15px 30px;
            border-bottom: 1px solid #e6e0ef;
        }

        header img {
            width: 220px;
            height: auto;
        }

        main {
            display: flex;
            justify-content: center;
            padding: 40px 15px;
        }

        .caixa {
            background-color: white;
            width: 100%;
            max-width: 450px;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.06);
        }

        h1 {
            color: #6f2dbd;
            font-size: 25px;
            margin-top: 0;
        }

        .campo {
            margin-bottom: 17px;
        }

        label {
            display: block;
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 7px;
        }

        input:not([type="checkbox"]) {
            width: 100%;
            padding: 12px;
            border: 1px solid #ded7e8;
            border-radius: 6px;
            font-size: 14px;
        }

        input:focus {
            outline: 1px solid #8e51d4;
        }

        .opcao {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .botao {
            width: 100%;
            padding: 13px;
            background-color: #6f2dbd;
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }

        .botao:hover {
            background-color: #572096;
        }

        .mensagem {
            background-color: #eee5fa;
            color: #572096;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .link {
            text-align: center;
            font-size: 14px;
            margin-top: 20px;
        }

        a {
            color: #6f2dbd;
        }

    </style>

</head>

<body>

    <header>
        <a href="../index.php">
            <img src="../assets/imagens/logo.jpg" alt="Loja e Amigos">
        </a>
    </header>

    <main>

        <div class="caixa">

            <h1>Criar minha conta</h1>

            <p>Preencha seus dados para participar da Loja e Amigos.</p>

            <?php

            if ($mensagem != "") {

                echo "<div class='mensagem'>";
                echo htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8");
                echo "</div>";

            }

            ?>

            <form method="POST" action="">

                <div class="campo">

                    <label for="nome">Nome completo</label>

                    <input
                        type="text"
                        name="nome"
                        id="nome"
                        maxlength="256"
                        value="<?php echo htmlspecialchars($nome, ENT_QUOTES, "UTF-8"); ?>"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="email">E-mail</label>

                    <input
                        type="email"
                        name="email"
                        id="email"
                        maxlength="256"
                        value="<?php echo htmlspecialchars($email, ENT_QUOTES, "UTF-8"); ?>"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="dataNascimento">Data de nascimento</label>

                    <input
                        type="date"
                        name="dataNascimento"
                        id="dataNascimento"
                        value="<?php echo htmlspecialchars($dataNascimento, ENT_QUOTES, "UTF-8"); ?>"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="senha">Senha</label>

                    <input
                        type="password"
                        name="senha"
                        id="senha"
                        minlength="8"
                        required
                    >

                </div>

                <div class="campo">

                    <label for="confirmarSenha">Confirmar senha</label>

                    <input
                        type="password"
                        name="confirmarSenha"
                        id="confirmarSenha"
                        minlength="8"
                        required
                    >

                </div>

                <div class="opcao">

                    <input
                        type="checkbox"
                        name="vendedor"
                        id="vendedor"
                        value="1"
                        <?php
                        if ($vendedor == 1) {
                            echo "checked";
                        }
                        ?>
                    >

                    <label for="vendedor">
                        Quero me cadastrar como vendedor.
                    </label>

                </div>

                <button type="submit" class="botao">
                    Criar conta
                </button>

            </form>

            <div class="link">

                Já possui uma conta?
                <a href="login.php">Fazer login</a>

            </div>

        </div>

    </main>

</body>

</html>
